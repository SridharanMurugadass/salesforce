angular.module("serviceApp")
.service('commonServices',function($http,$q,$sessionStorage,$filter){

	 //['CM','CSO','CIF','CSM','CPC','SM','CARE','CS','QUOTING','CPM']; //[{"id": "1","prodName": "CM"}, {"id": "2","prodName": "CSO"}, {"id": "3","prodName": "CIF"}, {"id": "4","prodName": "CSM"}, {"id": "5","prodName": "CPC"}, {"id": "6","prodName": "SM"}, {"id": "7","prodName": "CARE"}, {"id": "8","prodName": "CS"}, {"id": "9","prodName": "QUOTING"}, {"id": "10","prodName": "CPM"}];
	var allProducts = [{"id": "1","prodName": "CM"}, {"id": "2","prodName": "CSO"}, {"id": "3","prodName": "CIF"}, {"id": "4","prodName": "CSM"}, {"id": "5","prodName": "CPC"}, {"id": "6","prodName": "SM"}, {"id": "7","prodName": "CARE"}, {"id": "8","prodName": "CS"}, {"id": "9","prodName": "QUOTING"}, {"id": "10","prodName": "CPM"}];
	var allScreens = [{"id":"1","menuName":"Home","url":"#/"},{"id":"1","menuName":"Service Document","url":""},{"id":"1","menuName":"HLD Document","url":"#/blankPage"},{"id":"1","menuName":"LLD Document","url":"#/blankPage"},{"id":"1","menuName":"Blog","url":"#/blankPage"}];	
	var productsList = ['CM','CSO','CIF','CSM','CPC','SM','CARE','CS','QUOTING','CPM'];

	this.getUserRole = function(){
		var result = $filter('titlecase')( $sessionStorage.uname );
		var userID = '?accountName='+result;
		console.log('userID '+userID);
		return $http.get('/api/authorization'+userID);
	}

	/* This 'getProducts' common service is used to get the list of products, which is based on the user role */
	/*this.getProducts = function(){
		var userID = '?user_name='+$sessionStorage.uname;
		var url = '/api/authorization'+userID;
		var products = [];
		var role = '';		
		
		var promise = $http.get(url)
			.then(function(res){					
				if(res.data.length > 0){
					var datas = res.data[0].products_Name;
					role = res.data[0].role;
					console.log('this is from getUserRole '+role);
					/*var index = 1;
					angular.forEach(datas,function(data){
						products.push({"id": index,"prodName":data});
					});*/	
				/*}
				return res;
			},function(err){
				console.error("Error while retrieving authorization data");
				return $q.reject(err);
			});
		return role;
	}*/
	this.getAllProducts = function(){
		return allProducts;
	}

	this.getProductsList = function(){
		return productsList;
	}
	
}) /* This filter is used for convert lowercase to Title Case */
.filter('titlecase', function() {
    return function(s) {
        s = ( s === undefined || s === null ) ? '' : s;
        return s.toString().toLowerCase().replace( /\b([a-z])/g, function(ch) {
            return ch.toUpperCase();
        });
    };
});