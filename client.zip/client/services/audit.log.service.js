angular.module('serviceApp')
.service('logsService',function($http,$sessionStorage){

	this.logEvent = function(logEvent,logModule){
		console.log("this logEvent service length "+$sessionStorage.length);
   		
   			console.log("logEvent service entered with userName "+$sessionStorage.uname);
   			var userName =  $sessionStorage.uname;
   			var logs = {"user_Name":userName,"log_Event":logEvent,"log_Module":logModule,"log_Date":new Date()};
	      	var url = '/api/auditlog';
	      	//console.log(JSON.stringify(logs));
			$http.post(url,logs,function(response){
				console.log("logged success "+response);
		   
			});
			
   		
		
   		
   		
	}
});