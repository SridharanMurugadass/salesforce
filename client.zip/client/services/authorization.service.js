angular.module("serviceApp")
.service('authService',function($http,$q,$sessionStorage,$log){

	

	this.userAvailable = function(){
		//alert('authService : '+sessionStorage.length);
		if(sessionStorage.length > 0)
			return true;
		else
			return false;
	}

	this.userAccess = function(){
		if(sessionStorage.length > 0 && $sessionStorage.allAccess){
			return true;
		}
		else
			return false;
	}

	this.getGroupList = function(){
		var deferred = $q.defer();
		var url = '/api/authorization';
		$http.get(url)
				.then(function(response){
					deferred.resolve(response.data);
					//return deferred.promise;
				},function(response){
						//console.error("Error while retrieving authorization data");
					deferred.reject(response);
					
				});
		return deferred.promise;
	}

	this.fetch_Ldap_Users = function(){
		var deferred = $q.defer();
		var datas = '';
		 return $http.get('/users').then(function(response){
				deferred.resolve(response.data);
				console.log(response.data);
				return datas = response.data;
		},function(response){
			deferred.reject(response);
			console.log('this is err');	
			return deferred.promise;
		});	
		//return datas;
	}

	/*this.synchData = function(){		
		var serverData = this.fetch_Ldap_Users();
		if(serverData){
			alert("fetch_Ldap_Users : "+JSON.stringify(serverData));
		}else{
			alert("data not available");
		}
	}*/


	/*this.getGroupList = function(){
		var datas = [];
		var url = 'http://localhost:3000/api/authorization';
		var groups = $http.get(url).then(function(res){	
						angular.forEach(res.data,function(data){
							datas.push(data.user_Group_Name);
						});						
					},function(err){
						console.error("Error while retrieving authorization data");
						return $q.reject(err);
					});
		return datas;
	}*/

	
});