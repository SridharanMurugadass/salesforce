$(document).on('click', 'div.clickablel', function (e) {
    var $this = $(this);
   if($this.hasClass('panel-collapsed')){      
       $this.removeClass('panel-collapsed');
       $this.parents('.panel').find('.panel-body').slideUp();
       $this.parents('.panel').find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
   }else{      
       $this.parents('.panel').find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
       $this.addClass('panel-collapsed');
       $this.parents('.panel').find('.panel-body').slideUp();
       
   }
    
});
$(document).on('click', 'a.clickablel', function (e) {
    var $this = $(this);
   if($this.hasClass('panel-collapsed')){      
       $this.removeClass('panel-collapsed');
       $this.parents('.panel').find('.panel-body').slideUp();
       $this.parents('.panel').find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
   }else{      
       $this.parents('.panel').find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
       $this.addClass('panel-collapsed');
       $this.parents('.panel').find('.panel-body').slideUp();
       
   }
    
});
$(document).on('click', 'span.clickablel', function (e) {
    var $this = $(this);
    if ($this.hasClass('panel-collapsed')) {      
       
    }else{      
        $this.parents('.panel').find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
        $this.removeClass('panel-collapsed');
        $this.parents('.panel').find('.panel-body').slideDown();
    }
   
});
$(document).ready(function () {
   // $('.panel-heading span.clickablel').click();
   // $('.panel div.clickablel').click();
   // $('span.clickablel').click();
});
