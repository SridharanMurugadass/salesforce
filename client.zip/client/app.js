var serviceApp = angular.module('serviceApp',['ngRoute','ngStorage','ngResource',
						'ngAnimate', 'ui.bootstrap','ngSanitize','textAngular']);
//console.log('tsting... for function');
serviceApp.config(function($routeProvider){
//	console.log('tsting... for routeProvider function');
	$routeProvider.when('/',{
		controller:'ServiceController',
		templateUrl:'views/main.html'
	})
	.when('/blankPage',{ 
		controller:'ServiceController',
		templateUrl:'views/page_construction.html'
	})
	.when('/about/settings',{ 
		controller:'ServiceController',
		templateUrl:'views/about.html'
	})
	.when('/login',{ 
		controller:'ServiceController',
		templateUrl:'views/login.html'
	})
	/* .when('/auth',{ 		
		templateUrl:'views/user_auth.html',
		controller:'TestController',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable() && authService.userAccess()) {
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }
	}) */
	.when('/logoutPage',{
		controller:'LogoutController',
		templateUrl:'views/main.html'
	})
	/*.when('/test',{
		controller:'TestController',
		templateUrl:'views/service.html'
	})*/
	.when('/addhlddoc',{
		templateUrl:'views/add_hld_doc.html'
	})
	.when('/searchhld',{
		controller:'hlddocController',
		templateUrl:'views/search_hld_doc.html',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable())
				{
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }

	})
	.when('/viewhld',{
		templateUrl:'views/hld_doc_view.html'
	})
	.when('/addLldDoc',{
		templateUrl:'views/add_Lld_doc.html'
	})
	
	.when('/searchlld',{
		controller:'LlddocController',
		templateUrl:'views/search_Lld_doc.html',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable()) {
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }

	})
	
	.when('/viewLld',{
		templateUrl:'views/Lld_doc_view.html'
	})
	.when('/blogPage',{
		controller:'BlogController',
		templateUrl:'views/blog.html',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable()) {
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }
	})
	/* added for component */
	.when('/component',{
		controller:'ComponentController',
		templateUrl:'views/component.html',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable()) {
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }
	})
	/*.when('/serviceDetails/:id',{
		controller:'ServiceController',
		templateUrl:'views/service_details.html'
	})*/
	.when('/serviceList',{
		controller:'ServiceController',
		templateUrl:'views/service_list.html'
	})
	/* .when('/servicemain',{
		controller:'ServiceController',		
		templateUrl:'views/service_main.html',
		resolve: {
            precondition: ["$log", "$q", "authService", function ($log, $q, authService) {
                var deferred = $q.defer();                               
                if (authService.userAvailable()) {
                    $log.info("Route available");
                    deferred.resolve(true);
                } else {
                    $log.info("Route not available");
                    deferred.reject(false);
                }
                return deferred.promise;
            }]
        }
	}) */
	.otherwise({
		redirectTo: '/'
	})
});