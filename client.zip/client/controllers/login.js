var serviceApp = angular.module('serviceApp');
/*.service('testservice',function(){
	this.test = function(){
		return "hello";
	}
})*/
serviceApp.controller("test",
	function($scope,$http,$location,$routeParams,$route,$sessionStorage,
	commonServices){
	$scope.doit = function(data){
			alert("change this is from login  "+data);
			$scope.contacts = commonServices.list();

			//alert("change "+$scope.contacts);
			//$scope.getSelectedService(data);
		}
});

/// <reference path="services.js" />
 /** this service in Angular JS 
serviceApp.factory('loginService', function(){
	return{
		processLogin: function(){
			return "this test factory service";
		}
	};
});
*/
/*
var ActiveDirectory = require("activedirectory"),
	express = require("express");
var router = express.Router();


var username = '';
var password = '';

router.get('/', function(req, res){
	console.log("this login call "+req.body.username);
	username = req.body.username;
	password = req.body.password;

	var config = {
		url : 'ldap://10.90.1.23:389',
		baseDN: 'OU=century2,DC=centuryshield,DC=in',
	    username: username, //'ldapuser201',
	    password: password //'welcome3#'
	};

	console.log("this is config object "+JSON.stringify(config));

	var ad = new ActiveDirectory(config);

	ad.findUser('*', function (req, res, err, results) {
	    if (err) {
	        console.log('AD Login Failed: '+err);
	        res.send('Login Succeeded');
	    }
	    else{
	        console.log('AD Login Succeeded.'+JSON.stringify(results));
			res.send('Login not Succeeded');		
		}
	});

});*/
	


















































	/*var ActiveDirectory = require("activedirectory");
	var express = require('express');
	var router = express.Router();
	
	var bodyParser = require("body-parser");

	router.use(bodyParser.urlencoded({ extended : true}));
	router.use(bodyParser.json());




	// route middleware that will happen on every request
	router.use(function(req, res, next) {

	    // log each request to the console
	    console.log("Log for all request "+req.method, req.url);

	    // continue doing what we were doing and go to the route
	    next(); 
	});

	// define the home page route
	router.post('/', function(req, res) {
	 
	 var username = req.body.username;
	 var password = req.body.password;
	 var config = {
			url : 'ldap://10.90.1.23:389',
			baseDN: 'OU=century2,DC=centuryshield,DC=in',
		    username: username, //'ldapuser201',
		    password: password //'welcome3#'
		};

		console.log("this is config object "+JSON.stringify(config));

		var ad = new ActiveDirectory(config);
		
		ad.findUser('*', function (err, results) {
		    if (err) {
		        console.log('AD Login Failed: '+err);
		       // res.status(500).send("Invalid User Name");
		       // res.writeHead(200, {"Content-Type": "application/json"});
		       // res.redirect('/loginService')
		       res.send('#/ Invalid username')
		    }
		    else{
		        console.log('AD Login Succeeded.'+JSON.stringify(results));
	        
				//res.send('Login Succeeded');
				//res.status(200);
		       //res.redirect('/');	
			}
		});
		
	   	//next();
	  //console.log("this login call "+req.body.username);
		
	});

	router.post('loginService',function(req, res){
		res.end('this is login service')
	})
	// define the about route
	router.post('/error/:username', function(req, res, next) {
	 	res.send('No user named '+ req.params.username + ' found');
	 	next();	
	 //res.send('WHOOPS')
	});

module.exports = router;*/