var app = angular.module("serviceApp");
/*BlogController Starts*/
app.controller('BlogController', function ($scope,$window,$http,$sce,$location,
			   $rootScope,$sessionStorage,commonServices,logsService) {
	$scope.ShowWelcomePage = true;	
	/*This function is to call method from one controller to another*/ 
		  
	$rootScope.$on("CallParentMethod", function(){
		$scope.getReview();
	});
	
    /*This function is used to get reviews based on blog_Id*/
	$scope.getReview = function(Blog_Id){
		
        $http.get('/api/reviews/?Blog_Id='+Blog_Id).success(function(response){
        	$scope.reviewSelectedList = response;
			$scope.AddBlog = false;			
			$scope.calculateAverage();
		});
		
	}

	$scope.calculateAverage = function(){ 
		
		var len = $scope.reviewSelectedList.length;
		var sum = 0;
		for(var i = 0; i < len; i++){                                                                                  
	  		sum+= parseInt($scope.reviewSelectedList[i].rating);
	  	}
	 	var avg = (sum/len);
	 	$scope.average = avg;		
	};
    
	/*This function is to call recently added blog*/
	$scope.addBlog = function(){
	/* changes for loader*/
		$(".loader").css("display","block");
		$(".loaderimage").css("display","block");
		setTimeout(function(){
			$(".loader").css("display","none");
			$(".loaderimage").css("display","none");
			$scope.getBlogs();
		},1000);
	/* changes for loader*/
		
		//$scope.Blog = {};
		//$window.location.href = '#/blogPage';	
       //window.location.reload();
	}
	/* This function is to get all the blogs in search pannel */
	$scope.getBlogs = function(){
		var role = $sessionStorage.userRole;
		var userName = $sessionStorage.uname;
		$http.get('/api/blogs/detailList/'+role+'/'+userName).success(function(response){
			$scope.blogList = response; 
		});
		$scope.ShowWelcomePage = true;
		$scope.AddBlog = false;
		$scope.userRole = $sessionStorage.userRole; // to display approved or reject
		$scope.User_Name =  $sessionStorage.uname; // to send username as formparam into db 
		
     
	}		 	
		
		
	/*This function is to get the categories*/
	$scope.getCategories = function(){
		$http.get('/api/blogs').success(function(response){
			$scope.categories =  response;
		});
	}
	
	/*This function is used to approve the status of the blog when approve button is clicked*/			
	$scope.Approved_Status = function(Blog_Id){
		$scope.approved = true;
		$scope.reject = true;
		$scope.ShowReviewComments = false;
		$scope.Blog = {'Blog_Status':'approved'};
		$http.put('/api/blogs/'+Blog_Id,$scope.Blog).success(function(response){
			$scope.getBlogs();
			logsService.logEvent($scope.Blog_Subject+" blog has been approved ","Blog Controller");
			
		});	
	}
		

    /*This function is used to reject the status of the blog when reject button is clicked*/
    $scope.Reject_Status = function(Blog_Id){
		$scope.approved = true;
		$scope.reject = true;
		$scope.ShowReviewComments = false;
		$scope.Blog = {'Blog_Status':'reject'};
		$http.put('/api/blogs/'+Blog_Id,$scope.Blog).success(function(response){
			$scope.getBlogs();
			logsService.logEvent($scope.Blog_Subject+" blog has been rejected ","Blog Controller");
		
		});	
	}		

		
	/* This function is used to delete the blog (selected blog) from blogs list */
	$scope.deleteBlog = function(blogId){
		bootbox.confirm("Would you like to delete this Blog?", function(result) {
			$scope.Blog = {'Blog_Status':'delete'};
			$http.put('/api/blogs/'+blogId, $scope.Blog).success(function(response){
				$scope.getBlogs();
				logsService.logEvent($scope.Blog_Subject+" blog has been deleted ","Blog Controller");
			});
		}); 	 
	}
		   
		   
	/*This function is to clear the display message*/
	$scope.clearMessage = function(msgID){
		$(msgID).display='none';
		window.setTimeout(function() {
	        $(msgID).fadeTo(500, 0).slideUp(500, function(){
	        	$(this).remove(); 
			});
		}, 4000);
	}
				
		
	/* This function is used to pick the blog (selected blog) from blogs list */
	$scope.getblog = function(Blog_Id,filePath)
	{

			/* changes for loader*/
			$(".loader").css("display","block");
			$(".loaderimage").css("display","block");
			//$("#showComponentDetailsModal").css("display","none");
			setTimeout(function() 
			{
				
				$(".loader").css("display","none");
				$(".loaderimage").css("display","none");
				//$scope.getBlogs();
				//$("#showComponentDetailsModal").fadeIn(500);

			},1000);
			/* changes for loader*/
			$scope.ShowReviewComments = true;
			$scope.ShowWelcomePage = false;
			
			$http.get('/api/blogs/'+Blog_Id).success(function(response){
				$scope.blogSelectedList = response;
				$scope.blog_ReviewId = Blog_Id;
				$scope.getReview(Blog_Id);	
				logsService.logEvent($scope.Blog_Subject+" blog has been loaded ","Blog Controller");

				var filename = filePath.replace(/^.*[\\\/]/, '');
				$("#pdfViewer").html("");
				var pdfObjectTag = "<object width='100%' height='700px;'"+
									"data='/api/services/readPDF/"+filename+"' type='application/pdf'>"+
									"<embed width='100%' src='/api/services/readPDF/"+filename+"' "+
									"type='application/pdf'/></object>";

				$("#pdfViewer").append(pdfObjectTag);
			
		    });
		    $scope.approved = false;
			$scope.reject = false;
	}
		  
		
	/* This function is either to add or edit blog*/	
	$scope.submitForm = function(valid)
	{
    	if($scope.Blog._id ==  null){
			$scope.addBlogs(valid);	
			$scope.submitBtn = true;
		}
		else{
			$scope.submitBtn = false;
			$scope.updateBlogs($scope.Blog._id,valid); 
		}
	}
			
			
	/*This function for updating blog*/		
    $scope.updateBlogs = function(){

   	 /*window.setTimeout(function() 
	   {
		 		$scope.getBlogs();  
				}, 2000);*/

				/* changes for loader*/
			$(".loader").css("display","block");
			$(".loaderimage").css("display","block");
			//$("#showComponentDetailsModal").css("display","none");
			setTimeout(function() 
			{
				
				$(".loader").css("display","none");
				$(".loaderimage").css("display","none");
				$scope.getBlogs();
				//$("#showComponentDetailsModal").fadeIn(500);

			},2000);
			/* changes for loader*/
			
	 		

		   $window.location.href = "#/blogPage";
		   $scope.ShowReviewComments = false;
	  		//$scope.getBlogs();
		
		$scope.AddBlog = false;
		$scope.ShowWelcomePage = true;
				
		//$scope.showSubjectName = $scope.Blog.Blog_Subject;
		//$scope.updateMessage = true;
		//$scope.clearMessage('#updateMsg');
		//logsService.logEvent($scope.showSubjectName+" blog has been updated ","Blog Controller");
		//$scope.Blog = {};
	}
			
	
	/*This function for editing blog*/
    $scope.enableEditor = function(btnValue,Blog_Id){
		$scope.editorEnabled = false;
		$scope.showAddUpdateBtn = true;
		if(btnValue == 'edit'){
			$http.get("config.properties").then(function(response){		  
				$scope.serviceBlog = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_BLOG_UPDATE_URL);
			});
			$http.get('/api/blogs/'+Blog_Id).success(function(response){
			$scope.Blog = response;
			$scope.AddBlog = true;
			$scope.ShowReviewComments = false;
			});
			$scope.Blog = {};
			
		}
		else
		   {
		   		$http.get("config.properties").then(function(response){		  
					$scope.serviceBlog = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_BLOG_URL);			
				});
				$scope.AddBlog = true;
				$scope.ShowReviewComments = false;
				$scope.ShowWelcomePage = false;
				$scope.Blog = {};
			}		
	};
                   
    /*This function is used to close add blog once it is submitted*/
    $scope.closepanel = function() {
        $scope.AddBlog = false;
        $scope.ShowReviewComments = false;
        $scope.ShowWelcomePage=true;
		$scope.reset();
    }; 
	
	/*Style for menubar*/
	$scope.style = function(){	   
		$('#menuBar').css('display','block');
	}
	
	/*Reset add blog*/	 
	$scope.reset = function(){
    	$scope.Blog = {};
	}
	
	
});		
/*Blog Controller Ends*/	

/*This is to show trimed blog details in recent blog*/
app.filter('limitHtml', function() {
	return function(text, limit) {
	  var changedString = String(text).replace(/<[^>]+>/gm,'');
	  var length = changedString.length;
	  return changedString.length > limit ? changedString.substr(0, limit - 1)+"..." : changedString; 
	}
});

/*Review Controller Starts*/	
app.controller('ReviewController', function($scope,$http,$rootScope
											,$sessionStorage,logsService){
	$scope.ratingvalue = 0;
	$scope.ShowWelcomePage = false;  



		
	/*This function is used to add reviews*/
	$scope.addReviews = function(){
        $scope.review.create_Date = new Date();
		$scope.review.rating = $scope.ratingvalue;         
        $scope.review.Blog_Id = $("#blogg").val();
        $scope.review.User_Name = $sessionStorage.uname;
        $scope.review.User_Id = $sessionStorage.uname;
		$http.post('/api/reviews/',$scope.review).success(function(response){
	        $scope.getReview($scope.review.Blog_Id);
	        $scope.reset_review();
	        $scope.showComments = false;
	        logsService.logEvent($scope.Blog_Subject+" blog review has been added ","ReviewController");
        }); 
         
    }
	
    /*This function is to show reply text area for that particular comment*/
	
    $scope.showReplyBox = function(index,parentIndex,commentId,blogId){
        if(index){
            var replyBoxTemp = "<div ng-controller='ReviewController'><textarea id='replyComments"+index+"' ng-model='replyComments' cols='85' rows='3' style='resize:none;'></textarea>"+
                               '<button type="button" onclick="sendReply(\''+index+'\',\''+commentId+'\',\''+blogId+'\');" id="sendBtn" class="btn btn-primary">Send</button></div>';
            $("#replyBox"+index+"-"+parentIndex).append(replyBoxTemp);
        }
    }

	/*This function is to send the reply for particular comment*/                             
    sendReply = function(index,commentId,blogId){
        $scope.reply = $("#replyComments"+index).val();
        $scope.review = {"reply_comment"   : $scope.reply,
						 "reply_user_name" : $sessionStorage.uname,
        				 "reply_date" : new Date()};            
	    var commentsObject = '';
	    angular.forEach($scope.reviewSelectedList,function(key,value){
		    if(key._id == commentId){
		        commentsObject = key;
		    }
        });
        commentsObject.Reply.push($scope.review);
        $http.put('/api/reviews/'+commentId,commentsObject).success(function(response){
            console.log("reviews"+JSON.stringify(response));
            $scope.getReview(blogId);
    		$scope.reset_review();
   			$scope.showComments = false;
        	$scope.showReply = false;
		});                                                                           
    }

   /*see more values in comments*/  
	$scope.reviewValue = function(id,index){                                                           
		$('#'+index).show();
		$('#'+id).hide();
		$('#short'+index).hide();
	}
	$scope.reset_review = function(){           
		$scope.review = {Review_Details:'', rating:''};           
	}
	
    /*see more values in comments*/	  
    $scope.reviewValue = function(id,index){                                                           
        $('#'+index).show();
        $('#'+id).hide();
        $('#short'+index).hide();
    }
    $scope.reset_review = function(){           
        $scope.review = {Review_Details:'', rating:''};           
    }

	/*setting star value from directive*/		
	$scope.setStarsValue = function(starValue){
		$scope.ratingvalue = starValue;
	}
});

/*Review Controller Ends here*/

/*User defined directive for rating*/
 app.directive('inputStars', [function () {
    var directive = {
        restrict: 'EA',
        replace: true,
        template: '<tr>' +
        '<td ng-touch="paintStars($index)" '+
        'ng-mouseenter="paintStars($index, true)" '+
        'ng-mouseleave="unpaintStars($index, false)" '+
        'ng-repeat="item in items track by $index">' +
        '<i ng-class="getClass($index)" '+
        'ng-click="setValue($index, $event)"></i>' +
        '</td>' +
        '</tr>',
        require: 'ngModel',
        scope: true,
        link: link
    };
    return directive;
    function link(scope, element, attrs, ngModelCtrl) {
			
    var computed = {
        get readonly() {
            return attrs.readonly != 'false' && (attrs.readonly || attrs.readonly === '');
        },
        get fullIcon() {
            return attrs.iconFull || 'fa-star';
        },
        get emptyIcon() {
            return attrs.iconEmpty || 'fa-star-o';
        },
        get iconBase() {
            return attrs.iconBase || 'fa fa-fw';
        },
        get iconHover() {
            return attrs.iconHover || 'angular-input-stars-hover';
        }
    };

    scope.items = new Array(+attrs.max);
    scope.listClass = attrs.listClass || 'angular-input-stars';

    ngModelCtrl.$render = function () {
        scope.lastValue = ngModelCtrl.$viewValue || 0;
    };
            
    scope.getClass = function (index) {
        var icon = index >= scope.lastValue ? computed.iconBase + ' ' + computed.emptyIcon : computed.iconBase + ' ' + computed.fullIcon + ' active ';
        return computed.readonly ? icon + ' readonly' : icon;
    };

    scope.unpaintStars = function ($index, hover) {
        scope.paintStars(scope.lastValue - 1, hover);
    };
    
    scope.paintStars = function ($index, hover) {
        // ignore painting if readonly
        if (computed.readonly) {
            return;
        }

        var items = element.find('td').find('i');
		
        for (var index = 0; index < items.length; index++) {
            var $star = angular.element(items[index]);
              
            if ($index >= index) {
                $star.removeClass(computed.emptyIcon);
                $star.addClass(computed.fullIcon);
                $star.addClass('active');
                $star.addClass(computed.iconHover);
            } else {
                $star.removeClass(computed.fullIcon);
                $star.removeClass('active');
                $star.removeClass(computed.iconHover);
                $star.addClass(computed.emptyIcon);

            }
        }

        if (! hover) {
            items.removeClass(computed.iconHover);
        }
    };

    scope.setValue = function (index, e) {
        // ignore setting value if readonly
        if (computed.readonly) {
            return;
        }

        var star = e.target,
            newValue;

        if (e.pageX < star.getBoundingClientRect().left + star.offsetWidth / 2) {
            newValue = index + 1;
			
        } else {
            newValue = index + 1;
        }

        // sets to 0 if the user clicks twice on the first "star"
        // the user should be allowed to give a 0 score
        if (newValue == scope.lastValue && newValue == 1) {
            newValue = 0;
        }

        scope.lastValue =newValue;
		

        ngModelCtrl.$setViewValue(newValue);
        ngModelCtrl.$render();

        //Execute custom trigger function if there is one
        if(attrs.onStarClick){
            scope.$eval(attrs.onStarClick);
        }
	      
		
		// $scope.ratingvalue = scope.lastValue ;
    };
			 
    }// link end
}]);
/*User defined directive for rating ends here*/	