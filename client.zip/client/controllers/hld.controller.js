(function(){
var serviceApp = angular.module("serviceApp");

serviceApp.controller("hlddocController",function($scope,$http,$sce,
	commonServices, $window,$location,$sessionStorage,logsService){
		
		console.log("logEvent service entered with userName "+$sessionStorage.uname);

	$scope.products = commonServices.getAllProducts();
	//$scope.pdfViewer = "client/CIF_test562.docx.pdf";
	$scope.retrieveDocs = function(){
		//console.log("test pdf")
		//PDFObject.embed("http://10.90.4.70:9090/RestfulMultiFileStoreMongoDBExample/rest/files/download/file/ss.pdf", "#pdfViewer");
		//alert("load");
		$http.get("/api/hlddocs").success(function(response){
			$scope.documents = response;
		});
	}

	$scope.loadDocument = function(){
		var documentName = $location.search().projectName;
		if(documentName == null){ // add/upload new document
			$scope.submitBtn = true;
			$scope.reset();
		}else{ // retrieve selected document for update the details
			$http.get("/api/hlddocs/?projectName="+documentName).success(function(response){
				//$scope.filePath = response[0].pdfFileName;
				$scope.docId = response[0]._id;
				$scope.docs = response[0];
				$scope.submitBtn = false;
			});
		}
	}

	$scope.updateDocs = function(){
		/* changes for Loader */
            $(".loader").css("display","block");
            $(".loaderimage").css("display","block");
                setTimeout(function(){
                    $(".loader").css("display","none");
                    $(".loaderimage").css("display","none");
                    $("#uploadForm").submit();
                    $window.location.href = "#/searchhld";
                }, 1000);
        /* changes for Loader */
	
		logsService.logEvent($scope.docId+" Id has been Updated ","HLD Controller");		
	}

	$scope.addNewDoc = function(){
		$window.location.href = "#/addhlddoc";			
	}
	
	$scope.loadfile = function(filePath){
		//var filePath = $location.search().pdfFilePath
		//alert(filePath);
		var filename = filePath.replace(/^.*[\\\/]/, '');
		$("#pdfViewer").html("");
		//alert(filename);
		var pdfObjectTag = "<object width='100%' height='700px;'"+
							"data='/api/services/readPDF/"+filename+"' type='application/pdf'>"+
							"<embed width='100%' src='/api/services/readPDF/"+filename+"' "+
							"type='application/pdf'/></object>";

		$("#pdfViewer").append(pdfObjectTag);
			
	}
	$scope.backToSearch = function(){
		$window.location.href = "#/searchhld";
	}
	$scope.editDoc = function(projectID){
		$window.location.href = "#/addhlddoc?projectName="+projectID;
	}
	$scope.reset = function(){
	    $scope.docs = {};
	}


	$http.get("config.properties").then(function(response){
		if($scope.submitBtn){
			$scope.serviceHLD = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_HLD_URL);	
		}else{
			$scope.serviceHLD = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_HLD_UPDATE_URL);	
		}		
	});
	
});


}());