angular.module("serviceApp")
.controller("AuthorizationCntl",function($scope,$http,commonServices,
	authService,orderByFilter,$filter,logsService){	
	
	// Services call for retrieving datas
	$scope.products = commonServices.getAllProducts();
	
	$scope.panelTitle = "Add User Group Settings";
	$scope.auth = {};
	$scope.screens =  [{"id": "1","screenName": "screen 1"}, {"id": "2","screenName": "screen 2"}, {"id": "3","screenName": "screen 3"}];
	$scope.showMainPanel = true;
	$scope.showServiceMenu = true;


	
	/* This method used to synch datas from ldap-server to our application DB */
	$scope.synchUserDetails = function(){
		
		authService.fetch_Ldap_Users().then(function(result){
			var datas = result;			
			var index = 1;
			var userName = '';
			var userEmail = '';
			var accountName = '';
			angular.forEach(datas,function(data){
				userName = data.displayName;
				userEmail = data.mail;
				accountName = data.sAMAccountName;
				var usersDetails = '{"user_Id":"'+index+'","user_Name":"'+userName+'","user_EmailId":"'+userEmail+'","account_Name":"'+accountName+'"}';
				$http.post('api/userdetails',usersDetails).success(function(res){
					console.log('data insert successfully');				
				});
				index++;
			});			
			
		},function(error){
			console.log('this is error');
		});
		
	}

	/* This method is to perform the load Users in the user panel */
	$scope.loadUsers = function(){
		$http.get('/api/userdetails').success(function(res){
			//console.log('this is test from AuthorizationCntl ');
			$scope.users = res;
		});		
		/*$http.get('/users').then(function(result){
			$scope.users = result;
			console.log('success result');
		},function(errResult){
			console.log('Error while retrieving users datas : '+errResult);
		});*/
	}

	$scope.loadGroupList = function(){
		authService.getGroupList().then(function(result){
			$scope.groupList = result;
			console.log('Group list loaded ' +result);
			return result;
		},function(error){
			console.log("error while fetching datas : "+error.statusText);
			return error;
		});
	}

	/* This method is to perform the add or update authorization data into db */
	$scope.submitForm = function(valid){
		if(valid){
			if(!$scope.auth._id){
				$scope.saveAuthorization();
			}else{
				//alert($scope.auth._id);
				$scope.updateAuthorization($scope.auth._id);
			}
		}else{
			console.log("In valid form submit "+valid);
		}
	}

	/* Insert Operation - This method is to perform the add the new user group and configuration details into DB */
	$scope.saveAuthorization = function(){
		alert("$scope.auth "+JSON.stringify($scope.auth));
		$http.post('api/authorization',$scope.auth).success(function(res){
			$scope.saveMessage = true;
			$scope.showUGSettingPanel = false;
			$scope.showUserGrpName = $scope.auth.user_Group_Name;
			$scope.clearMessage('#saveMsg');
			console.log('1 record added '+res);			
			$scope.loadGroupList();
			logsService.logEvent($scope.showUserGrpName+" has been added ","Authorization Controller");
		});
	}


	/* Update Operation - This method is to perform the update the selected user group and configuration details into DB */
	$scope.updateAuthorization = function(userGroupID){
		$http.put('api/authorization/'+userGroupID,$scope.auth).success(function(res){
			$scope.updateMessage = true;
			$scope.showUGSettingPanel = false;
			$scope.showUserGrpName = $scope.auth.user_Group_Name;
			$scope.clearMessage('#updateMsg');
			authService.getGroupList().then(function(result){

				$scope.groupList = result;
			},function(error){console.log("error while fetching datas : "+error.statusText);});
			console.log('1 record updated ');
			logsService.logEvent($scope.showUserGrpName+" has been updated ","Authorization Controller");
		});
	}

	/* Delete Operation - This method is to perform the delete the selected user group from DB */
	$scope.deleteUserGroup = function(userGroupID){
		bootbox.confirm("Would you like to delete this User Group ?", function(result) {
		  if(result){
		  	$http.delete('api/authorization/'+userGroupID).success(function(res,status){
				console.log('1 record deleted ');
				if(status == 204){
					$scope.loadGroupList();
					$scope.closePanel();
				} 
			});
			logsService.logEvent($scope.userGroupID+" ID has been deleted ","Authorization Controller");
		  }
		});
	}
	/* UI - This method is to perform collect all-checked data from products list */
	$scope.checkAll = function(){
		angular.forEach($scope.products, function(product){
			product.selected = (product.selected)?false:true;
		});
		$scope.getSelectedProducts();
	}
	/*$scope.checkAllScreen = function(){
		angular.forEach($scope.screens, function(screen){
			screen.selected = true;
		});
		$scope.getSelectedScreens();
	}*/

	/* UI - This method is to perform the random selection of product from products list*/
	$scope.getSelectedProducts = function(){
		$scope.productsArr = [];
		angular.forEach($scope.products, function(product){
			if(product.selected) $scope.productsArr.push(product.prodName);
		});
		//alert($scope.productsArr);
		$scope.auth.products_Name = $scope.productsArr;
	}
	/*$scope.getSelectedScreens = function(){
		$scope.screensArr = [];
		angular.forEach($scope.screens, function(screen){
			if(screen.selected) $scope.screensArr.push(screen.screenName);
		});
		$scope.auth.screen_privilege = $scope.screensArr;
	}*/

	/* UI - This method is to perform the random selection of user from users list*/
	$scope.getSelectedUsers = function(){
		$scope.usersArr = [];
		$scope.userAccArr = [];
		angular.forEach($scope.users, function(user){
			if(user.selected){
				$scope.usersArr.push(user.user_Name);
				$scope.userAccArr.push($filter('titlecase')(user.account_Name));
			} 
		})
		$scope.auth.user_name = $scope.usersArr;
		$scope.auth.accountName = $scope.userAccArr;
	}

	

	/* Retrieve Operation - This method is to perform retrieve operation for selected user group from DB and show in view */
	$scope.retrieveUserGrpDetails = function(groupID){
		$scope.showMainPanel = false;
		$scope.showUGSettingPanel = true;

		$http.get('/api/authorization/'+groupID).success(function(result){
			$scope.auth = result;
			var selectedProducts = result.products_Name;
			var selectedUsers = result.user_name;
			$scope.panelTitle = "Update User Group Settings";


			$scope.uncheckAll($scope.products);
			angular.forEach(selectedProducts,function(selectedProduct){
				angular.forEach($scope.products,function(product,index){
					if(selectedProduct == product.prodName){
						$scope.products[index].selected = true;
						return 1;
					} 
				});
			});
			$scope.uncheckAll($scope.users);
			angular.forEach(selectedUsers,function(selectedUser){
				angular.forEach($scope.users,function(user,index){
					if(selectedUser == user.user_Name){
						$scope.users[index].selected = true;
						return 1;
					} 
				});
			});
			// checked users order by asc
			$scope.users = orderByFilter($scope.users,"selected",true);



		});
	}


	/* UI - This method is to perform show 'add user group' panel, while click the 'plus' icon */
	$scope.addUserGroupForm = function(){
		$scope.showMainPanel = false;
		$scope.showUGSettingPanel = true;
		$scope.panelTitle = "Add User Group Settings"; // changing the panel title
		$scope.reset();
		$scope.uncheckAll($scope.products);
		$scope.uncheckAll($scope.users);

		/*angular.forEach($scope.groupList,function(group){
			console.log((group.user_name == 'Guna Palani'));
		});*/

	}

	/* UI - This method is used to un-check all the check-box which is checked */
	$scope.uncheckAll = function(dataList){
		angular.forEach(dataList,function(data){
			data.selected = false;
		})
	}

	/* UI - This method is used to reset the form data, while click 'plus' icon */
	$scope.reset = function(){
      	$scope.auth = {};
      	$scope.authorizationForm.$setPristine(); //reset Form
  	}

  	/** UI - This function is used to clear the status message **/
	$scope.clearMessage = function(msgID){
		$(msgID).display='none';
		window.setTimeout(function() {
		    $(msgID).fadeTo(500, 0).slideUp(500, function(){
		        $(this).remove(); 
		    });
		}, 4000);
	}

	/** UI - This function is used to close the (add or update) panel based on condition **/
	$scope.closePanel = function() {
	  	$scope.showMainPanel = true;
		$scope.showUGSettingPanel = false;
	};

	
});

$(document).on('click', '.panel-heading span.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.parents('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
	} else {
		$this.parents('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
	}
})

/*angular.module("serviceApp").directive('autoComplete',function($timeout){
	return function(scope,iElement, iAttrs){
		iElement.autocomplete({
			source:scope[iAttrs.uiItems],
			select: function(){
				$timeout(function(){
					iElement.trigger('input');
				},0);
			}
		});
	}
});*/



