	var sApp = angular.module("sApp",[]);

	sApp.controller("ServiceController1",['$scope','$http','$location','$routeParams', function($scope,$http,$location,$routeParams){
		console.log('ServiceController1 loaded1111**************');
		$scope.getServices = function(){
			$http.get('/api/services').success(function(response){
				$scope.services =  response;
			});
		}

	}]);