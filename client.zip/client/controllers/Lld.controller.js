(function(){
    var serviceApp = angular.module("serviceApp");
    serviceApp.controller("LlddocController",function($scope,$http,$sce,
                                       commonServices, $window,$location,logsService)
    {
       

        $scope.documentPanel=true;
        $scope.products = commonServices.getAllProducts();

        $scope.retrieveDocs = function()
        {
	        $http.get("/api/Llddocs").success(function(response)
	        {
	            $scope.documents = response;
	           //alert("documents"+JSON.stringify($scope.documents));
	        });
        }

        $scope.loadDocument = function()
        {
	        var documentName = $location.search().projectName;
	        var moduleID = $location.search().moduleID;
	        if(documentName == null)
            { // add/upload new document
                $scope.submitBtn = true;
                $scope.reset();
            }else
            { // retrieve selected document for update the details
	            $http.get("/api/Llddocs/?projectName="+documentName).success(function(response)
	            {
		            //$scope.filePath = response[0].pdfFileName;
		            //console.log("response for loadDocument"+JSON.stringify(response));
                    $scope.submitBtn = false;
		            $scope.docId = response[0]._id;
		            $scope.docs = response[0];
		            $.each($scope.docs.moduleID,function(k,v)
		            {
		            //alert(" "+k + " "+v.moduleID);
			            if(v.moduleID == moduleID)
			            {
			                $scope.docs.moduleID.moduleName = v.moduleName;
			                $scope.docs.moduleID.shortDescription = v.shortDescription;
			                $scope.docs.moduleID.docVersion = v.docVersion;
			                $scope.docs.moduleID.searchMetadata = v.searchMetadata;
			                $scope.docs.moduleID.moduleid = v.moduleID;
			            }
	               });
	                $scope.moduleID = response[0].moduleID;
	                
				});
            }
        }
        
        $scope.updateDocs = function()
        {
        /* changes for Loader */
            $(".loader").css("display","block");
            $(".loaderimage").css("display","block");
            setTimeout(function(){
                $(".loader").css("display","none");
                $(".loaderimage").css("display","none");
                $("#uploadForm").submit();
                $window.location.href = "#/searchlld";
            }, 1000);
        /* changes for Loader */
        }
        	

        $scope.addNewDoc = function()
        {
            $window.location.href = "#/addLldDoc";                              
        }

        $scope.editDoc = function(projectID,moduleID)
        {
            $window.location.href = "#/addLldDoc?projectName="+projectID+"&moduleID="+moduleID;
        }

        $scope.loadfile = function(filePath)
        {
            //$scope.documentPanel=false;
            var filename = filePath.replace(/^.*[\\\/]/, '');
            $("#pdfViewer").html("");
            var pdfObjectTag = "<object width='100%' height='700px;'"+
            "data='/api/services/readPDF/"+filename+"' type='application/pdf'>"+
            "<embed width='100%' src='/api/services/readPDF/"+filename+"' "+
            "type='application/pdf'/></object>";
            $("#pdfViewer").append(pdfObjectTag);
        }

		$scope.backToSearch = function()
		{
            $window.location.href = "#/searchlld";
        }


		$scope.deleteLld = function(documentName,projectID,moduleID)
        {
            var moduleObject={};
            //alert("documentName"+documentName+"projectID   "+projectID+"moduleID  "+moduleID);
            bootbox.confirm("Would you like to delete this documents?", function(result) 
            {
				if(result)
				{
					$http.get("/api/Llddocs/?projectName="+documentName).success(function(response)
		            {
		                $scope.docs = response;              
		               	$.each($scope.docs,function(key,value)
						{
			                $.each(value.moduleID,function(key1,value1)
			                {
			                	
				                if(value1.moduleID == moduleID)
				                {
				                   //alert("value1.moduleID  "+value1.moduleID+" moduleID "+moduleID);
				                    value1.moduleStatus = "inactive";
				                }
				            });           
			                moduleObject = {"moduleID" :value.moduleID};
			                //alert("value.moduleID"+JSON.stringify(value.moduleID));
			                //alert("value.moduleID"+JSON.stringify(moduleObject)+"projectID  "+projectID);
			                 //alert("after update value1.moduleID"+JSON.stringify(value1.moduleStatus));
			                $http.put("/api/Llddocs/"+projectID,moduleObject).success(function(response)
		           			{
			                     //console.log("deleted successfully "+JSON.stringify(response));
			                    $scope.documentPanel=true;
			                   	$window.location.reload();
			                    logsService.logEvent(documentName+" has been deleted ","Service Controller");
			                });
		                 });
		            });
	        	}
        	});
		}

		$scope.reset = function()
       	{
             $scope.docs = {};
        }

          /*This function is used to get notification about Component */

	    $scope.clearMessage = function(msgID)
	    {
			$(msgID).display='none';
			window.setTimeout(function() {
			    $(msgID).fadeTo(500, 0).slideUp(500, function(){
			        $(this).remove(); 
			    });
			}, 4000);
		}

		
		$http.get("config.properties").then(function(response){
            if($scope.submitBtn){
                $scope.serviceLLD = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_LLD_URL);           
            }else{
                $scope.serviceLLD = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_LLD_UPDATE_URL);         
            }
		});
    });

	
}());
