var serviceApp = angular.module("serviceApp");

serviceApp.config(['$routeProvider', '$httpProvider', function($routeProvider, $httpProvider) {
    $httpProvider.defaults.cache = false;
    if (!$httpProvider.defaults.headers.get) {
      $httpProvider.defaults.headers.get = {};
    }
    // disable IE ajax request caching
    $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
    //.....here proceed with your routes
}]);

serviceApp.controller("ServiceController",['$scope','$http','$location','$sessionStorage','commonServices','logsService',
		function($scope,$http,$location,$sessionStorage,commonServices,logsService){
		console.log('ServiceController loaded');




		commonServices.getUserRole().then(function(result){
			if(result.data.length > 0){
				console.log("Access : "+result.data[0].role);
				$sessionStorage.userRole = result.data[0].role;
				if(result.data[0].role == 'Read'){
					$scope.writeAccess = false;
				}else if(result.data[0].role == 'Write'){
					$scope.writeAccess = true;
				}else if(result.data[0].role == 'All'){
					$scope.writeAccess = true;
					$scope.deleteAccess = true;
					$scope.allAccess = true;				
				}
			}else{
				$scope.writeAccess = false; // if role is not define, default Read access only
				console.log('Record not found');
			}
			
		},function(error){
			console.log("error while fetching datas : "+error.statusText);
		});

		
		$scope.add_editPage = '/views/add_edit_service.html';
		$scope.serviceListPage = '/views/service_list.html';
		$scope.menuBar_Selected_Product = '';
		$scope.service = {}; //{id:null,productName:'',serviceGroup:'',name:'',uri:'',desc:'',requestType:'',requestParam:'',request:'',response:''};
		$scope.showServiceDetailsPanel = true;
		$scope.showServiceMenu = (sessionStorage.length == 0)?false:true;
		$scope.search = '';
		var serviceLoaded = false;
		/* getServices method to get all the services, currently not used */
		$scope.getServices = function(){
			$http.get('/api/services').success(function(response){
				console.log('get services method calling');
				$scope.services =  response;
				//$scope.style();
				//console.log('get services method datas  '+response);
				serviceLoaded = true;
			});
		}

		$scope.loadAllServices = function(){
			if($scope.checkall){
				$scope.allsearch = '';
				console.time("Start");
				if(!serviceLoaded) $scope.getServices();
					console.time("End");
			}			
		}
		
		/* addServices method to add new service */
		$scope.addServices = function(valid){
			if(valid){
				$http.post('/api/services/',$scope.service).success(function(response){
					//$scope.getServices();
					$scope.getSelectedService($scope.service.productName);
					$scope.saveMessage = true;
					$scope.clearMessage('#saveMsg');
					$scope.showServiceDetailsForm = false;
					$scope.showServiceName = $scope.service.name;
					$scope.reset();
					logsService.logEvent($scope.showServiceName+" has been added ","Service Controller");       	    	
				});
			}else{
				console.log("In valid form submit "+valid);
			}
		}

		/** This function is used to pick the service (selected service) from services list **/
		$scope.getService = function(serviceId){
			var id = serviceId;//$routeParams.id;
			$scope.editorEnabled = true;
			$scope.showServiceDetailsPanel = false;
			$http.get('/api/services/'+id).success(function(response){
				
				$scope.service = response;
				$scope.showServiceDetailsForm = true;
				$scope.panelTitle = "Service Details"; // changing the panel title
				$scope.showAddUpdateBtn = false;
				
			});
						
		}
		/** This function is used to update the service details (selected service) **/
		$scope.updateService = function(serviceId,valid){
			if(valid){
				var id = serviceId; //$routeParams.id;
				console.log('ServiceController update a service details with id : '+id);
				$http.put('/api/services/'+id, $scope.service).success(function(response){
					//$scope.getServices();
					$scope.getSelectedService($scope.menuBar_Selected_Product);
					$scope.updateMessage = true;
					$scope.showServiceDetailsForm = false;
					$scope.clearMessage('#updateMsg');
					$scope.showServiceName = $scope.service.name;
					$scope.reset();
					logsService.logEvent($scope.showServiceName+" has been updated ","Service Controller");       	    	
				});
				
				$scope.panelTitle = "Service Details"; // changing the panel title	
			}else{
				console.log("Invalid form submitted "+valid);
			}
			
		}

		$scope.getSelectedService = function(product){
			//alert(product);
			$scope.menuBar_Selected_Product = product;

			$http.get('/api/services/'+product).success(function(response){				
				$scope.ddata =  response;
				//$scope.style();
				//alert(response);
				//console.log('getSelectedService method datas  '+response);
			});			
		}

		/** This function is used to delete the service (selected service) from services list **/
		$scope.deleteService = function(serviceId,serviceName){
		
			bootbox.confirm("Would you like to delete this service? "+ serviceName, function(result) {
			  if(result){
			  	var service_name =  serviceName;
			  	$http.delete('/api/services/'+serviceId, $scope.service).success(function(response){
					//$scope.getServices();
					$scope.getSelectedService($scope.menuBar_Selected_Product);
					$scope.closePanel();
					logsService.logEvent(service_name+" has been deleted ","Service Controller");       	    	
				});
			  }
			 	
			}); 
			
		}

		/** This function is used to call the addService or updateService based on condition **/
		$scope.submitForm = function(valid){

			if($scope.service._id ==  null){
				$scope.addServices(valid);
			}else{
				$scope.updateService($scope.service._id,valid); 
			}
		}
		
		/** This function is used to show the add panel or update panel based on condition **/
		$scope.enableEditor = function(btnValue){
		    $scope.editorEnabled = false;
		    $scope.showAddUpdateBtn = true;
		    $scope.showServiceDetailsPanel = false;
			if(btnValue == 'edit'){
				$scope.panelTitle = "Update Service Details"; // changing the panel title
			}else{ // add 
				$scope.showServiceDetailsForm = true;
				$scope.panelTitle = "Add New Service"; // changing the panel title
				$scope.reset();
			}
		}
		/** This function is used to close the (add or update) panel based on condition **/
		$scope.closePanel = function() {
		  	$scope.showServiceDetailsForm = false;
		  	$scope.showServiceDetailsPanel = true;
		};

		/** This function is used to clear the status message **/
		$scope.clearMessage = function(msgID){
			$(msgID).display='none';
			window.setTimeout(function() {
			    $(msgID).fadeTo(500, 0).slideUp(500, function(){
			        $(this).remove(); 
			    });
			}, 4000);
		}

		/** This function is used to clear the form value **/
		$scope.reset = function(){
	          $scope.service = {id:null,productName:'',serviceGroup:'',name:'',uri:'',desc:'',requestType:'',requestParam:'',request:'',response:''};
	          $scope.serviceForm.$setPristine(); //reset Form
	      }
		
		$scope.serviceInit = function(){
			
			$scope.showServiceMenu = true;
			//alert('this is from ServiceController');
			
			//$('#menuBar').css('display','block'); /* this menu bar in service_main.html */
			//$('#mainMenu').css('display','none'); /* this main menu in index.html */
			
		}

				
		// Gloabal variabls
		$scope.isDisabled = true;
		$scope.products = commonServices.getAllProducts(); //getProducts(); 
		/*$scope.products = commonServices.getProdcts().then(function(d){
			return d;
		});*/
		//['CM','CSO','CIF','CSM','CPC','SM','CARE','CS','QUOTING','CPM'];
		$scope.panelTitle = "Service Details"; // changing the panel title
		
        $scope.arr = Array.apply(null,{length: $scope.products.length/2}).map(Number.call,Number);
	
	}]);

serviceApp.controller("MainController",function($scope){

		$scope.menuShow = function(){
			//alert('this is from MainController');
			//$('#menuBar').css('display','none');
			//$('#mainMenu').css('display','block'); /* this main menu in index.html */
		}

});


serviceApp.controller("TestController",function($scope,$http){

		
		/*console.log('TestController loaded1111**************');
		$scope.getServicesm = function(product){
			console.log('getServicesm ************** >>> '+product);
			$http.get('/api/services/'+product).success(function(response){
				console.log('ok done');
				$scope.data =  response;
				console.log('ok data '+response);
			});
		}
*/
});




/* This login controller used to connect ldap system to authenticate the user login */
serviceApp.controller("LoginController",function($scope,$http,$location,
	$timeout,$sessionStorage,$window,logsService,commonServices){

	$scope.data = {}
    $scope.response = {}
    $scope.centuryDashBoard = [
    	{"moduleName":"Service Document",
    	 "pageURL":"#/servicemain",
    	 "iconName":"glyphicon glyphicon-th-list"
    	},
    	{"moduleName":"HLD Documents",
    	 "pageURL":"#/searchhld",
    	 "iconName":"glyphicon glyphicon-pencil"
    	},
    	{"moduleName":"LLD Documents",
    	 "pageURL":"#/searchlld",
    	 "iconName":"glyphicon glyphicon-pencil"
    	},
    	{"moduleName":"Blog",
    	 "pageURL":"#/blogPage",
    	 "iconName":"glyphicon glyphicon-user"
    	},
    	{"moduleName":"Reusable Components",
    	 "pageURL":"#/component",
    	 "iconName":"glyphicon glyphicon-th"
    	},
    	{"moduleName":"Bulletin Board",
    	 "pageURL":"#/blankPage",
    	 "iconName":"glyphicon glyphicon-bitcoin"
    	}];
    $scope.loggedIn = (sessionStorage.length == 0)?true:false;
    $scope.pageURL = '#/';
    $scope.dashBoardList = ['Services Document','HLD Documents','LLD Document','Blog','Reusable Components'];
    //$scope.uid = sessionStorage.length;
    $scope.obj = {}
    $scope.sessionObj = {}
    if(sessionStorage.length > 0) $scope.uid = $sessionStorage.uname;		
	
    /*$scope.send = function(){
    	$scope.obj.toggle2 = true
    	$("#dlDropDown").dropdown("toggle");
    }*/
    $scope.Out = function(){
    	logsService.logEvent($sessionStorage.uname+ " LogOut successfully","Login controller");       	    	
    	console.log('this is logout method');
    	$scope.obj.toggle2 = false;
    	$("#loDropDown").dropdown("toggle");
    	delete $sessionStorage.uname;
    	delete $sessionStorage.allAccess;
    	delete $sessionStorage.userRole;	
		//$location.path('#/logoutPage');		
		$window.location.href = "/";
		
		//alert("$scope.obj.toggle2 : "+$scope.obj.toggle2);
    }

    $scope.Init = function(){
    	$scope.obj.toggle2 = (sessionStorage.length == 0)?false:true;//false; 
    	//$scope.sessionObj.LogIN = (sessionStorage.length == 0)?false:true;
    	/*if(!$scope.sessionObj.LogIN){
    		$scope.uid = $sessionStorage.uname;
    	}
    	console.log("$scope.obj.toggle2 : "+$scope.obj.toggle2)
    	console.log("$scope.sessionObj.LogIN  : "+$scope.sessionObj.LogIN + " : "+$scope.uid)*/
    }
    

    $scope.In = function () {
        /*executed when submit is clicked*/
        
       //var date = new Date();
       //$scope.hhmmsstt = $filter('date')(new Date(), 'hh:mm:ss a');
       //console.log('loging time 1 : '+date);
        if($scope.data.username != null && $scope.data.password != null){
        	
	        var posting = $http({
	            method: 'POST',	            
	            url: '/loginauth',
	            data: $scope.data,

	            processData: false
	        })
	        posting.success(function (response) {
	            /*executed when server responds back*/
	            
	            console.log(response.loginStatus);
	            //console.log(response);
	            if(response.loginStatus == 'failure'){
	            	/* Incorrect username or password. message display */
	            	$scope.showMessage = true;
	            	/* clear the login-form data */
	            	$scope.data.username = ''; 
	            	$scope.data.password = ''; 
	            	/* fade in error message */
	            	$timeout(function() {
	            		  $scope.showMessage = false;			    
					}, 3000);
					logsService.logEvent("Login button clicked and login failure","Login controller");
	            }
	            if(response.loginStatus == 'success'){	        	    	
        	    	$sessionStorage.uname = response.sessVar.username;
        	    	$scope.uid = $sessionStorage.uname;
        	    	
        	    	/*$scope.$apply(function () {
			            $scope.message = "Timeout called!";
			        });*/
			        $scope.obj.toggle2 = true;
        			$scope.data.username = ''; 
            		$scope.data.password = ''; 
         			$("#dlDropDown").dropdown("toggle");

         			commonServices.getUserRole().then(function(result){
						if(result.data.length > 0){
							//console.log(" LoginController Access : "+result.data[0].role);				
							$sessionStorage.userRole = result.data[0].role;
							if(result.data[0].role == 'All'){					
								$scope.allAccess = true;
								$sessionStorage.allAccess = true;
							}
						}else{
							$scope.allAccess = false; // if role is not define, default Read access only
							console.log('Record not found');
						}
						
					},function(error){
						console.log("error while fetching datas : "+error.statusText);
					});	 
         			logsService.logEvent($sessionStorage.uname+" LoggedIn successfully","Login controller");       	    	
	            }                       
	        });	        
    	}  
    }
    
    $scope.servicePage = function(pageName){    	
		if(sessionStorage.length == 0){			
		    bootbox.alert({
		        message: "please log in to proceed!",
		        size: 'small'
		    });
		}else{			
			$window.location.href = pageName;
		}

	}		

});

