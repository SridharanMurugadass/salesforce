var app = angular.module("serviceApp");
 
app.controller('ComponentController', function($scope,$http,logsService,$sce) 
{
   		$scope.showComponentDetailsPanel = true;

		/*This function is used to pick the Components List*/

		$scope.getComponents = function()
		{
			$http.get('/api/components').success(function(response)
			{
			$scope.ComponentList =  response;
			});
		}

		/*This function is used to retrieve  Component Name from form*/
    	$scope.getComponentNames = function()
    	{
        	$http.get('/api/components').success(function(response)
        	{
			$scope.ComponentNames =  response;
			
			});
		}


		/** This function is used to pick the Component (selected Component) from Components list **/
		$scope.getComponent = function(ComponentId)
		{
		/* changes for loader*/
			$(".loader").css("display","block");
			$(".loaderimage").css("display","block");
			//$("#showComponentDetailsModal").css("display","none");
			setTimeout(function(){
				$(".loader").css("display","none");
				$(".loaderimage").css("display","none");
			},1000);
		/* changes for loader*/

			$scope.editorEnabled = true;
			$scope.showComponentDetailsPanel = false;
			
			$http.get('/api/components/'+ComponentId).success(function(response)
			{
				$scope.user = response;

				$scope.showComponentDetailsForm = true;
				$scope.panelTitle = "Component Details"; // changing the panel title
				$scope.showAddUpdateBtn = false;

				var filename = $scope.user.pdfFileName.replace(/^.*[\\\/]/, '');//filepath.replace(/^.*[\\\/]/, '');
				//alert(filename+" ===== "+$scope.user.pdfFileName);
				$("#pdfViewer").html("");
				//alert(filename);
				var pdfObjectTag = "<object width='100%' height='700px;'"+
									"data='/api/services/readPDF/"+filename+"' type='application/pdf'>"+
									"<embed width='100%' src='/api/services/readPDF/"+filename+"' "+
									"type='application/pdf'/></object>";

				

				$("#pdfViewer").append(pdfObjectTag);
				
			});
						
		}

		/*This function is used to Enable or disable the Component Details*/

		$scope.enableEditor = function(btnValue)
		{
			
		    $scope.editorEnabled = false;
		    $scope.showAddUpdateBtn = true;
		    $scope.showComponentDetailsPanel  = false;
			if(btnValue == 'edit'){
				$scope.submitBtn = false;

				$http.get("config.properties").then(function(response){	
					$scope.serviceComponent = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_COMPONENT_UPDATE_URL);				
				});

				$scope.panelTitle = "Update Component Details";// changing the panel title

			}
			else{ // add
				$scope.submitBtn = true;
				$scope.showComponentDetailsForm = false;
				$scope.showComponentDetailsForm = true;
			    $http.get("config.properties").then(function(response){					
					$scope.serviceComponent = $sce.trustAsResourceUrl(response.data.ServerURL+response.data.Service_COMPONENT_URL);								
				});
				$scope.panelTitle = "Add New Component"; 
				$scope.user={};
			}

		}

		/*This function is used to update Details from Selected Component */
		
		$scope.updateDocs = function()
		{
			$scope.showComponentDetailsPanel = true;
	  		$scope.showComponentDetailsForm = false;
			// window.setTimeout(function() 
			// {
			//     $("#uploadForm").submit();
			// }, 500);
			$("#uploadForm").submit();

			/* changes for loader*/
				$(".loader").css("display","block");
				$(".loaderimage").css("display","block");
				
				setTimeout(function() {

					$(".loader").css("display","none");
				    $(".loaderimage").css("display","none");
				   	
				}, 2000);
			/* changes for loader*/
			logsService.logEvent("Components details has been Updated ","Component Controller");		
		}

		/* This function is used to delete the Component (selected Component) from Components list*/
		$scope.deleteComponent = function(ComponentId)
		{
			bootbox.confirm("Would you like to delete this service?", function(result) {
			  if(result){
			  	$http.delete('/api/components/'+ComponentId, $scope.user).success(function(response){
				$scope.getComponents();
				});
			  }
			 	
			}); 
		}

		/*This function is used to get notification about Component */

	    $scope.clearMessage = function(msgID)
	    {
			$(msgID).display='none';
			window.setTimeout(function() {
			    $(msgID).fadeTo(500, 0).slideUp(500, function(){
			        $(this).remove(); 
			    });
			}, 4000);
		}

		/*This function is used to rediect homePage*/
		$scope.closePanel = function() {
			$scope.showComponentDetailsPanel = true;
		  	$scope.showComponentDetailsForm = false;
		};

});



	

	
	

  


 
