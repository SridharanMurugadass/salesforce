function Connection(object) {
    this.x = parseInt(object.x);
    this.y = parseInt(object.y);
}