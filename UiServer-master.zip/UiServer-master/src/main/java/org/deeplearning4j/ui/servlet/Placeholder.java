package org.deeplearning4j.ui.servlet;

/**
 * @author sridharanbe.ece@gmail.com
 */
public class Placeholder {
}
