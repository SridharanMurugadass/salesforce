Import JSON file in Typescript

Article here: https://hackernoon.com/import-json-into-typescript-8d465beded79#.uuabhfg3j

1. Download it. 
2. Run `npm install`
3. Run `npm start` 