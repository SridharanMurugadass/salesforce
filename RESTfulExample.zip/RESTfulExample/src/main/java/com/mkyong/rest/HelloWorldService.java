package com.mkyong.rest;
 
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
 
@Path("/mongo")
public class HelloWorldService {
 
	@POST
	@Path("/register")
	public Response StoreDB(@FormParam("name") String name,
	@FormParam("LastName") String lname,
	@FormParam("email") String email,
	@FormParam("telephone") String phone,
	@FormParam("address") String address,
	@FormParam("password") String pass,
	@FormParam("password2") String cpass){
 
		Mongo m = new Mongo("localhost",27017);
		DB db = m.getDB("htmlpage");
		DBCollection collect = db.getCollection("service");
		
		BasicDBObject obj = new BasicDBObject();
		obj.put("name", name);
		obj.put("lname", lname);
		obj.put("email", email);
		obj.put("phone", phone);
		obj.put("address", address);
		obj.put("pass", pass);
		obj.put("cpass", cpass);
		
		collect.insert(obj);
		
		
 
		return Response.status(500).entity("created successfully").build();
 
	}
	
	@POST
	@Path("/signin")
	public Response signinDB(@FormParam("username") String name,
			@FormParam("password") String pass){
		Mongo m = new Mongo("localhost",27017);
		DB db = m.getDB("htmlpage");
		DBCollection collect = db.getCollection("service");
		
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("name", name);
		whereQuery.put("pass", pass);
		
		
		DBCursor cursor = collect.find(whereQuery);
		
		
		
		if(cursor.hasNext()==true){
			
			return Response.status(500).entity("login successfully").build();
		}else{
			
			return Response.status(500).entity("login failed").build();
		}
		
		
		
		
	
		
		
	}
			
	
	
 
}