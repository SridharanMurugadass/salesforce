/********************************************************************************************************
 *  File Name     : DocService.java                                                              *                       
 *  Author        : @author Sridharan.M                                                                 *    
 *  Owner         : Drivereal Technologies                                                              *
 *  Created Date  : 01/12/2016                                                                          *          
 *  Modified Date : 02/15/2017                                                                         *          
 *  Usage         : Upload File Rest Services                                                           *                         
 *                                                                                                      *
 ********************************************************************************************************
 * Revision History                                                                                     *
 * Version  |        Date     |    Author                     |Description                              *
 *          |                 |                               |                                         *
 *******************************************************************************************************/
package com.drivereal.app.services.service;

import java.io.InputStream;
import java.util.logging.Logger;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

public interface DocService {

	final static Logger LOGGER = Logger.getLogger(DocService.class.getName());

	@POST
	@Path("/MainMenu")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadMainMenu(@FormDataParam("file") InputStream uploadedInputStream, @FormDataParam("file") FormDataContentDisposition fileDetail,
			@FormDataParam("mainMenuName") String mainMenuName, @FormDataParam("mainOrderType") String mainOrderType);

	@POST
	@Path("/SubMenu")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadSubMenu(@FormDataParam("file") InputStream uploadedInputStream, @FormDataParam("file") FormDataContentDisposition fileDetail,
			@FormDataParam("subMenuName") String subMenuName, @FormDataParam("mainMenuName") String mainMenuName, @FormDataParam("subOrderType") String subOrderType);

}
