/********************************************************************************************************
 *  File Name     : DocController.java                                                              *                       
 *  Author        : @author Sridharan.M                                                                 *    
 *  Owner         : Drivereal Technologies                                                              *
 *  Created Date  : 01/04/2017                                                                         *          
 *  Modified Date : 02/15/2017                                                                          *          
 *  Usage         : Upload File Rest Services                                                           *                         
 *                                                                                                      *
 ********************************************************************************************************
 * Revision History                                                                                     *
 * Version  |        Date     |    Author                     |Description                              *
 *          |                 |                               |                                         *
 *******************************************************************************************************/
package com.drivereal.app.services.controller;

import java.io.InputStream;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import com.drivereal.app.services.Dao.MainMenuDao;
import com.drivereal.app.services.Dao.SubMenuDao;
import com.drivereal.app.services.service.DocService;
import com.sun.jersey.core.header.FormDataContentDisposition;

@Path("/service")
public class DocController implements DocService {

	public DocController() {
	}

	@Context
	private UriInfo Context;

	Response result = null;

	public Response uploadMainMenu(InputStream uploadedInputStream, FormDataContentDisposition fileDetail, String mainMenuName, String mainOrderType) {

		result = MainMenuDao.uploadMainMenu(uploadedInputStream, fileDetail, mainMenuName, mainOrderType);

		return null;
	}

	public Response uploadSubMenu(InputStream uploadedInputStream, FormDataContentDisposition fileDetail, String subMenuName, String mainMenuName, String subOrderType) {

		result = SubMenuDao.uploadSubMenu(uploadedInputStream, fileDetail, subMenuName, mainMenuName, subOrderType);

		return null;
	}

}
