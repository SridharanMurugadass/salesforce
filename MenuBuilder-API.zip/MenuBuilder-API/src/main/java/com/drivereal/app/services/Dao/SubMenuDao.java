/********************************************************************************************************
 *  File Name     : LldDao.java                                                              *                       
 *  Author        : @author Sridharan.M                                                                 *    
 *  Owner         : Drivereal Technologies                                                              *
 *  Created Date  : 01/12/2016                                                                          *          
 *  Modified Date : 02/15/2017                                                                         *          
 *  Usage         : Upload File Rest Services                                                           *                         
 *                                                                                                      *
 ********************************************************************************************************
 * Revision History                                                                                     *
 * Version  |        Date     |    Author                     |Description                              *
 *          |                 |                               |                                         *
 *******************************************************************************************************/
package com.drivereal.app.services.Dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;
import java.util.logging.Logger;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import com.drivereal.app.services.util.ServiceUtils;
import com.drivereal.app.services.service.DocService;
import com.drivereal.app.services.Dao.Impl.MongoDBimpl;
import com.sun.jersey.core.header.FormDataContentDisposition;

public class SubMenuDao {

	private final static Logger LOGGER = Logger.getLogger(SubMenuDao.class.getName());

	public static Response uploadSubMenu(InputStream uploadedInputStream, FormDataContentDisposition fileDetail, String subMenuName, String mainMenuName, String subOrderType) {

		String inFile = null;
		String URIPAGE = null;
		String DB_URL = null;
		try {
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream inputStream = classLoader.getResourceAsStream("config.properties");
			Properties prop = new Properties();

			LOGGER.info("inputStream :: " + inputStream);

			if (inputStream != null) {
				try {
					prop.load(inputStream);
				} catch (IOException e) {

					e.printStackTrace();
				}
			} else {
				try {
					throw new FileNotFoundException("property file '" + inputStream + "' not found in the classpath");
				} catch (FileNotFoundException e) {

					e.printStackTrace();
				}
			}

			String UPLOAD_FOLDER = prop.getProperty("UPLOAD_FOLDER");
			URIPAGE = prop.getProperty("URIPAGE");
			DB_URL = prop.getProperty("DB_URL");
			prop.getProperty("ServerURL");

			if (uploadedInputStream == null || fileDetail == null)
				return Response.status(400).entity("Invalid form data").build();

			try {
				ServiceUtils.createFolderIfNotExists(UPLOAD_FOLDER);
			} catch (SecurityException se) {
				return Response.status(500).entity("Can not create destination folder on server").build();
			}

			inFile = UPLOAD_FOLDER + subMenuName + "_" + fileDetail.getFileName();

			try {
				ServiceUtils.saveToFile(uploadedInputStream, inFile);

				MongoDBimpl.storeDataToDBSUB(subMenuName, mainMenuName, subOrderType, inFile, DB_URL);
			} catch (IOException e) {
				return Response.status(500).entity("Can not save file").build();
			} catch (Exception e) {

				e.printStackTrace();
			}

		} finally {
			try {

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
		ResponseBuilder builder = null;

		try {

			builder = Response.seeOther(new URI(URIPAGE));

		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return builder.build();

	}

}
