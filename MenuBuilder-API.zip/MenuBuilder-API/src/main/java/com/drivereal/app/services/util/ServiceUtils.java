/********************************************************************************************************
 *  File Name     : ServiceUtils.java                                                              *                       
 *  Author        : @author Sridharan.M                                                                 *    
 *  Owner         : Drivereal Technologies                                                              *
 *  Created Date  : 01/12/2016                                                                          *          
 *  Modified Date : 02/15/2017                                                                          *          
 *  Usage         : Upload File Rest Services                                                           *                         
 *                                                                                                      *
 ********************************************************************************************************
 * Revision History                                                                                     *
 * Version  |        Date     |    Author                     |Description                              *
 *          |                 |                               |                                         *
 *******************************************************************************************************/
package com.drivereal.app.services.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ServiceUtils {

	public static void saveToFile(InputStream inStream, String target) throws IOException {
		OutputStream out = null;
		int read = 0;
		byte[] bytes = new byte[1024];

		out = new FileOutputStream(new File(target));
		while ((read = inStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}

	public static void createFolderIfNotExists(String dirName) throws SecurityException {
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
	}
}
