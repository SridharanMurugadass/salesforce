/********************************************************************************************************
 *  File Name     : MongoDBimpl.java                                                              *                       
 *  Author        : @author Sridharan.M                                                                 *    
 *  Owner         : Drivereal Technologies                                                              *
 *  Created Date  : 01/12/2016                                                                          *          
 *  Modified Date : 02/15/2017                                                                          *          
 *  Usage         : Upload File Rest Services                                                           *                         
 *                                                                                                      *
 ********************************************************************************************************
 * Revision History                                                                                     *
 * Version  |        Date     |    Author                     |Description                              *
 *          |                 |                               |                                         *
 *******************************************************************************************************/
package com.drivereal.app.services.Dao.Impl;

import java.net.UnknownHostException;
import java.util.UUID;
import java.util.logging.Logger;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

public class MongoDBimpl {

	private final static Logger LOGGER = Logger.getLogger(MongoDBimpl.class.getName());

	public static void storeDataToDBMAIN(String mainMenuName, String mainOrderType, String inFile, String DB_URL) {

		LOGGER.info("enters");
		try {

			Mongo mongo = new Mongo(DB_URL, 27017);
			DB db = mongo.getDB("menuList");
			DBCollection collection = db.getCollection("menuList");

			BasicDBObject module = new BasicDBObject();
			module.put("mainMenuName", mainMenuName);
			module.put("mainOrderType", mainOrderType);
			module.put("inFile", inFile);
			
			collection.insert(module);
			
			DBCursor cursorDoc = collection.find();
			while (cursorDoc.hasNext()) {
				System.out.println(cursorDoc.next());
			}

			LOGGER.info("success");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}

	}

	public static void storeDataToDBSUB(String subMenuName, String mainMenuName, String mainOrderType, String inFile, String DB_URL) {

		LOGGER.info("enters");

		try {

			Mongo mongo = new Mongo(DB_URL, 27017);
			DB db = mongo.getDB("menuList");
			DBCollection collection = db.getCollection("menuList");
			
			BasicDBObject updateQuery = new BasicDBObject();
			updateQuery.put("mainMenuName", mainMenuName);

			BasicDBObject module = new BasicDBObject();
			module.put("subMenuName", subMenuName);
			module.put("mainOrderType", mainOrderType);
			module.put("inFile", inFile);
			

			BasicDBObject updateCommand = new BasicDBObject();
			updateCommand.put("$push", new BasicDBObject("moduleID", module));
			WriteResult result = collection.update(updateQuery, updateCommand, true, true);

			LOGGER.info("success");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

}
