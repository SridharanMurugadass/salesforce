package com.innovate.rest;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import com.excelacom.rest.Converter;
import com.excelacom.rest.Docx2Pdf;
 
@Path("/file")
public class HelloWorldService {
	
	public HelloWorldService() {
	}

	@Context
	private UriInfo context;
	
	
 
	@POST
	@Path("/convert")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response fileConvert(String inputJson) {
		
		System.out.println("check"+inputJson);
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map = mapper.readValue(inputJson, new TypeReference<Map<String, String>>(){});
		} catch (JsonParseException e1) {
			
			e1.printStackTrace();
		} catch (JsonMappingException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
		System.out.println(map);
		 Object outFile1 = map.values().toArray()[0];
		    Object inFile1 = map.values().toArray()[1];
		    String inFile=inFile1.toString();
		    String outFile=outFile1.toString();
		
		    String lowerCaseInPath = inFile.toLowerCase();
		
		    
		    Converter converter = null;
		    
		 try
		    {
		      InputStream inStream = getInFileStream(inFile);
		      OutputStream outStream = getOutFileStream(outFile);
		      
		      if(lowerCaseInPath.endsWith("docx")){
		    	  converter = new Docx2Pdf(inStream, outStream, true, true);
		 		 }else if(lowerCaseInPath.endsWith("doc")){
		 			 converter = new DocToPDFConverter(inStream, outStream, true, true); 
		 		 }else if(lowerCaseInPath.endsWith("ppt")){
		 			 converter = new PptToPDFConverter(inStream, outStream, true, true); 
		 		 }else if(lowerCaseInPath.endsWith("pptx")){
		 			 converter = new PptxToPDFConverter(inStream, outStream, true, true); 
		 		 }else if(lowerCaseInPath.endsWith("odt")){
		 			 converter = new OdtToPDF(inStream, outStream, true, true); 
		 		 }
		      
		      if (converter == null) {
		        System.out.println("Unable to determine type of input file.");
		      } else {
		        try
		        {
		          converter.convert();
		        }
		        catch (Exception e)
		        {
		          e.printStackTrace();
		        }
		      }
		    }
		    catch (Exception e)
		    {
		      System.out.println("\n\nInput\\Output file not specified properly."); 
		    
		    }
		   // Converter converter;
		  
		return null;
 
	}
	
	 protected static InputStream getInFileStream(String inputFilePath)
			    throws FileNotFoundException
			  {
			    File inFile = new File(inputFilePath);
			    FileInputStream iStream = new FileInputStream(inFile);
			    return iStream;
			  }
			  
			  protected static OutputStream getOutFileStream(String outputFilePath)
			    throws IOException
			  {
			    File outFile = new File(outputFilePath);
			    try
			    {
			      outFile.getParentFile().mkdirs();
			    }
			    catch (NullPointerException localNullPointerException) {}
			    outFile.createNewFile();
			    FileOutputStream oStream = new FileOutputStream(outFile);
			    return oStream;
			  }
 
}