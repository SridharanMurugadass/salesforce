package com.drivereal.grocery.services.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Main application to run boot application.
 * 
 * @author Sridharan Murugadass
 * @version 1.0
 */

@SpringBootApplication
@ComponentScan(basePackages = "com.drivereal.grocery.services")
public class GroceryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryAppApplication.class, args);
	}
}
