package com.drivereal.grocery.services.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.drivereal.grocery.services.dao.CustomerProfileDAO;
import com.drivereal.grocery.services.entity.CustomerProfile;
import com.drivereal.grocery.services.util.MyCassandraTemplate;

@Repository
public class CustomerProfileDAOImpl implements CustomerProfileDAO {

	@Autowired
	private MyCassandraTemplate myCassandraTemplate;

	@Override
	public CustomerProfile createCustomerProfile(CustomerProfile customerProfile) {
		return myCassandraTemplate.create(customerProfile);

	}

	@Override
	public CustomerProfile getCustomerProfile(int customerId) {
		return myCassandraTemplate.findById(customerId, CustomerProfile.class);

	}

	@Override
	public CustomerProfile updateCustomerProfile(CustomerProfile customerProfile) {
		return myCassandraTemplate.update(customerProfile, CustomerProfile.class);

	}

	@Override
	public void deleteCustomerProfile(int customerId) {
		myCassandraTemplate.deleteById(customerId, CustomerProfile.class);

	}

	@Override
	public List<CustomerProfile> getAllCustomerProfile() {
		return myCassandraTemplate.findAll(CustomerProfile.class);

	}

}
