package com.drivereal.grocery.services.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.drivereal.grocery.services.entity.CustomerProfile;
import com.drivereal.grocery.services.service.CustomerProfileService;

/**
 * @author Sridharan Murugadass
 * @version 1.0
 * @since july 21, 2017
 */
@RestController
public class CustomerProfileController {

	@Autowired
	private CustomerProfileService customerProfileService;

	public CustomerProfileController() {
		System.out.println("CustomerProfileController()");
	}

	@RequestMapping(value = "/customerProfile", method = RequestMethod.POST)
	CustomerProfile create(@RequestBody CustomerProfile customerProfile) {
		return customerProfileService.createCustomerProfile(customerProfile);
	}

	@RequestMapping(value = "/customerProfile/{id}", method = RequestMethod.DELETE)
	void delete(@PathVariable("id") int customerId) {
		customerProfileService.deleteCustomerProfile(customerId);
	}

	@RequestMapping(value = "/customerProfile", method = RequestMethod.GET)
	List<CustomerProfile> findAll() {
		return customerProfileService.getAllCustomerProfile();
	}

	@RequestMapping(value = "/customerProfile/{id}", method = RequestMethod.GET)
	CustomerProfile findById(@PathVariable("customerId") int customerId) {
		return customerProfileService.getCustomerProfile(customerId);
	}

	@RequestMapping(value = "/customerProfile", method = RequestMethod.PUT)
	CustomerProfile update(@RequestBody CustomerProfile customerProfile) {
		return customerProfileService.updateCustomerProfile(customerProfile);
	}
}
