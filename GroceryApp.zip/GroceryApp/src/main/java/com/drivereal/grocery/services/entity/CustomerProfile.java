package com.drivereal.grocery.services.entity;

import java.sql.Date;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;

/**
 * Employee entity class.
 * 
 * @author sridharan Murugadass
 * @version 1.0
 */
@Table("customer_profile")
public class CustomerProfile {

	@PrimaryKey("customer_id")
	private int customerId;

	@Column("customer_name")
	private String customerName;

	@Column("area")
	private String area;

	@Column("city")
	private String city;

	@Column("email")
	private String email;

	@Column("date")
	private Date date;

	@Column("lattitude")
	private Float lattitude;

	@Column("longitude")
	private Float longitude;

	@Column("mobile")
	private int mobile;

	@Column("mobile_identification")
	private String mobileIdentification;

	@Column("phone")
	private int phone;

	@Column("state")
	private String state;

	@Column("status")
	private String status;

	@Column("street")
	private String street;

	@Column("zip")
	private String zip;

	/**
	 * Default Constructor
	 */
	public CustomerProfile() {
		super();
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Float getLattitude() {
		return lattitude;
	}

	public void setLattitude(Float lattitude) {
		this.lattitude = lattitude;
	}

	public Float getLongitude() {
		return longitude;
	}

	public void setLongitude(Float longitude) {
		this.longitude = longitude;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public String getMobileIdentification() {
		return mobileIdentification;
	}

	public void setMobileIdentification(String mobileIdentification) {
		this.mobileIdentification = mobileIdentification;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public CustomerProfile(int customerId, String customerName, String area, String city, String email, Date date,
			Float lattitude, Float longitude, int mobile, String mobileIdentification, int phone, String state,
			String status, String street, String zip) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.area = area;
		this.city = city;
		this.email = email;
		this.date = date;
		this.lattitude = lattitude;
		this.longitude = longitude;
		this.mobile = mobile;
		this.mobileIdentification = mobileIdentification;
		this.phone = phone;
		this.state = state;
		this.status = status;
		this.street = street;
		this.zip = zip;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "CustomerProfile [customerId=" + customerId + ", customerName=" + customerName + ", area=" + area
				+ ", city=" + city + ", email=" + email + ", date=" + date + ", lattitude=" + lattitude + ", longitude="
				+ longitude + ", mobile=" + mobile + ", mobileIdentification=" + mobileIdentification + ", phone="
				+ phone + ", state=" + state + ", status=" + status + ", street=" + street + ", zip=" + zip + "]";
	}

}
