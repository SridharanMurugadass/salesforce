package com.drivereal.grocery.services.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drivereal.grocery.services.dao.CustomerProfileDAO;
import com.drivereal.grocery.services.entity.CustomerProfile;
import com.drivereal.grocery.services.service.CustomerProfileService;

/**
 * Service Impl class for CustomerProfile to perform CRUD operation.
 * 
 * @author Sridharan Murugadass
 * @version 1.0
 */
@Service
public class CustomerProfileServiceImpl implements CustomerProfileService {

	@Autowired
	private CustomerProfileDAO customerProfileDAO;

	/**
	 * Default Constructor
	 */
	public CustomerProfileServiceImpl() {
		super();
	}

	@Override
	public CustomerProfile createCustomerProfile(CustomerProfile customerProfile) {
		return customerProfileDAO.createCustomerProfile(customerProfile);
	}

	@Override
	public CustomerProfile getCustomerProfile(int customerId) {
		return customerProfileDAO.getCustomerProfile(customerId);
	}

	@Override
	public CustomerProfile updateCustomerProfile(CustomerProfile customerProfile) {
		return customerProfileDAO.updateCustomerProfile(customerProfile);
	}

	@Override
	public void deleteCustomerProfile(int customerId) {
		customerProfileDAO.deleteCustomerProfile(customerId);
	}

	@Override
	public List<CustomerProfile> getAllCustomerProfile() {
		return customerProfileDAO.getAllCustomerProfile();
	}

}
