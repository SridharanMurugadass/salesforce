package com.drivereal.grocery.services.dao;

import java.util.List;
import com.drivereal.grocery.services.entity.CustomerProfile;

/**
 * DAO interface for CustomerProfile to perform CRUD operation.
 * 
 * @author Sridharan Murugadass
 * @version 1.0
 */
public interface CustomerProfileDAO {
	/**
	 * Used to Create the CustomerProfile Information
	 * 
	 * @param CustomerProfile
	 * @return {@link CustomerProfile}
	 */
	public CustomerProfile createCustomerProfile(CustomerProfile customerProfile);

	/**
	 * Getting the CustomerProfile Information using Id
	 * 
	 * @param id
	 * @return {@link CustomerProfile}
	 */
	public CustomerProfile getCustomerProfile(int customerId);

	/**
	 * Used to Update the CustomerProfile Information
	 * 
	 * @param CustomerProfile
	 * @return {@link CustomerProfile}
	 */

	public CustomerProfile updateCustomerProfile(CustomerProfile customerProfile);

	/**
	 * Deleting the CustomerProfile Information using Id
	 * 
	 * @param id
	 */
	public void deleteCustomerProfile(int customerId);

	/**
	 * Getting the All CustomerProfiles information
	 * 
	 * @return
	 */
	public List<CustomerProfile> getAllCustomerProfile();
}
