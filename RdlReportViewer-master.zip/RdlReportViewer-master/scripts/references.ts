/// <reference path="../../dts/angularjs/angular.d.ts" />
/// <reference path="../../dts/underscore/underscore.d.ts" />
/// <reference path="../../dts/mathjs/math.d.ts" />

 