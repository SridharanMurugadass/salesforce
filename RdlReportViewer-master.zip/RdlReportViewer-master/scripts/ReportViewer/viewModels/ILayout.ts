﻿module ReportViewer {
    export interface ILayout {
        columnCount: number;
    }
}