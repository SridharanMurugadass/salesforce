﻿module ReportViewer {
    export interface IChart extends IItem {
        height: number;
        data: any;
    }
}