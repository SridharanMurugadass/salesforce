﻿module ReportViewer {
    export interface IParameter {
        type: string;
        name: string;
        value: any;
    }
} 