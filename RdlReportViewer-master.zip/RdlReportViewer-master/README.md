# RdlReportViewer
This is a project for rendering microsoft RDL reports using angularjs.
Wouldn't it be cool if you could just render any RDL report in your own single page web application without having to use Microsoft not so pretty and not SPA compliant report viewer.
well this project does that exactly

