// import dlg from './';
// import dialogTemplate from 'text-loader!../../../../template/processor/dialog.html'; 

// var views = {};

// model view
var TagView = Backbone.View.extend({
  tagName: 'tr',

  initialize: function (options) {
    // Ensure our methods keep the `this` reference to the view itself
    _.bindAll(this, 'render');

    this.model.bind('change', this.render);
  },

  render: function () {
    $(this.el).empty();

    $(this.el).append($('<td class="v-table-cell-content" style="width: 316px;"><div class="v-table-cell-wrapper" style="text-align: left; width: 316px;">' + this.model.get('tagID') + '</div></td>'));
    $(this.el).append($('<td class="v-table-cell-content" style="width: 82px;"><div class="v-table-cell-wrapper" style="text-align: left; width: 82px;">' + this.model.get('itemID') + '</div></td>'));
    $(this.el).append($('<td class="v-table-cell-content" style="width: 99px;"><div class="v-table-cell-wrapper" style="text-align: left; width: 99px;">' + this.model.get('valueType') + '</div></td>'));
    $(this.el).append($('<td class="v-table-cell-content" style="width: 652px;"><div class="v-table-cell-wrapper" style="text-align: left; width: 652px;">' + this.model.get('tagPath') + '</div></td>'));
    $(this.el).append($('<td class="v-table-cell-content" style="width: 297px;"><div class="v-table-cell-wrapper" style="text-align: left; width: 297px;">' + this.model.get('description') + '</div></td>'));

    return this;
  }
});

var TagsView = Backbone.View.extend({
  collection: null,

  el: '#tagsList',

  initialize: function (options) {
    this.collection = options.collection;
    // alert('e value: filtering-init: '+this.collection);
    // Ensure our methods keep the `this` reference to the view itself
    _.bindAll(this, 'render');

    // Bind collection changes to re-rendering
    this.collection.bind('reset', this.render);
    // this.collection.bind('add', this.render);
    // this.collection.bind('remove', this.render);
  },

  render: function () {
    var element = $(this.el);
    element.empty();

    this.collection.forEach(function (item) {

      // Instantiate a tagItem view for each
      var itemView = new TagView({
        model: item
      });

      element.append(itemView.render().el);
    });

    return this;
  }
});

var FilteringView = Backbone.View.extend({
  // filterCollection: null,

  el: $('body'),

  events: {
   'click #bType': 'updateBoolean'
    // ,
    // 'click #iType': 'updateInteger',
    // 'click #fType': 'updateFloat',
    // 'click #sType': 'updateString',
    // 'click #specific': 'updateMachine'
  },

  // template : _.template($('#filteringTemplate').html()),

  initialize: function () {
    // this.filterCollection = options.filterCollection;
    // alert('e value: filtering-init: '+this.filterCollection);
    // this.filterCollection.bind('reset', this.render);
    // this.listenTo('#bType', 'change', this.render);
  },

  render: function () {
    alert('e value: filtering-render');
    // modify collection using .&_filter function
    // this.$el.html(this.template);
    // return this;
  },

  updateBoolean: function (e) {
    alert('cb value: ||');
    
    // var filtered = new FilteredCollection(coursesPaginated);

    // var boolType_Tags = Tags.where({
    //   valueType: "Boolean"
    // });

    // return new Tags(boolType_Tags);

    // if is checked
    // if (e.checked) {
      // var filtered = _.filter(this.collection.models, function (item) {
      //   return item.get("valueType") === "Boolean";
      // });

      //not used at the moment
      //filtered.filterBy('price', function(item) {
      //  return item.get('price') < 100;
      //});

      //this does not work
      //this.collection.reset(filtered2);

      //so I do this
      // this.collection.set(filtered);

    // } else {
      //something that I do not use at the moment
      //filtered.removeFilter('price');
    // }

  }
});

// var DialogView = Backbone.View.extend({
//   el: $('#TagUI.Add'),

//   // template: _.template($('#mainDialog').html()),

//   initialize: function () {
//     // alert('e value: dialog-init');
//     this.render();
//   },

//   render: function () {
//     // alert('e value: dialog-render');
//     // this.$el.html(this.template);
//     return this;
//   }
// });

// import views from './views';

var Router = Backbone.Router.extend({
  routes: {
    '': 'index'
  },

  index: function() {
    // normally you'd instantiate an empty list and call tags.fetch()
    // to get the data from your backend
    var tags = new model.Tags([
      {
        tagID: "Machine0_161130185117280TRC",
        itemID: "TRC",
        valueType: "Integer",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.DATA.TotalRejectCount",
        description: ""
      },
      {
        tagID: "Machine0_161130185117280JobID",
        itemID: "JobID",
        valueType: "String",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.JOB.JobID",
        description: ""
      },
      {
        tagID: "Machine0_161130185TRC",
        itemID: "TRC",
        valueType: "Integer",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.DATA.TotalRejectCount",
        description: ""
      },
      {
        tagID: "Machine0_161130185117280JobID",
        itemID: "JobID",
        valueType: "Boolean",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.JOB.JobID",
        description: ""
      },
      {
        tagID: "Machine0_161130185117280TRC",
        itemID: "TRC",
        valueType: "Float",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.DATA.TotalRejectCount",
        description: ""
      },
      {
        tagID: "Machine0_161130185JobID",
        itemID: "JobID",
        valueType: "String",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.JOB.JobID",
        description: ""
      },
      {
        tagID: "Machine0_161130185TRC",
        itemID: "TRC",
        valueType: "Boolean",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.DATA.TotalRejectCount",
        description: ""
      },
      {
        tagID: "Machine0_161130185JobID",
        itemID: "JobID",
        valueType: "Float",
        tagPath: "RNA://$Global/CPGApp/Area/[pm_perf]Machine0_161130185117280.JOB.JobID",
        description: ""
      }
      ]);

    var view = new TagsView({
      collection: tags
    });

    view.render();

    var filteringView = new FilteringView({
      // filterCollection: tags
    });

    filteringView.render();

    // var dialogView = new DialogView({
    // });
  }
});

$(function() {
  // When the document is ready we instantiate the router
  var router = new Router();

  // And tell Backbone to start routing
  Backbone.history.start();
});
