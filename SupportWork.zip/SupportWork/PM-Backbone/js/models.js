// Models are where actual data is kept. They can also be used
// for communicating between the server and the client through
// methods like save() and fetch().
//
// Models are the abstract data and do not know how they are
// supposed to be visualized.
var model = {};

model.Tag = Backbone.Model.extend({

});

model.Tags = Backbone.Collection.extend({
  model: model.Tag
});
