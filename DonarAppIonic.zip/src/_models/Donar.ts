export class Donar {
    mobile: string;
    name: string;
    address: string;
    area: string;
    city: string;
    state: string
    country: string;
    zipcode: string;
    bloodGroup: string;
}