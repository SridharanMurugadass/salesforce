import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Dashboard } from '../dashboard/dashboard';
import { UserLogin } from '../user-login/user-login';
import { UserSignup } from '../user-signup/user-signup';
import { SelectSearchable } from "../../components/select/select";



@IonicPage()
@Component({
  selector: 'page-user-forgotpassword',
  templateUrl: 'user-forgotpassword.html',
})
export class UserForgotpassword {

    donar={};
   //BloodGroups=[];
   //search
     BloodGroups: BloodGroup[];
     SelectedBloodGroup: BloodGroup;

   constructor(public navCtrl: NavController, public navParams: NavParams) {
     // this.BloodGroups=['0+','A+','AB+','B+'];
      this.BloodGroups = [
            {  name: '0+'  },
            {  name: 'B+' },
            { name: 'AB+' },
             { name: 'AB-' },
           
        ];
   
  }

  ionViewDidLoad() {}

  dashboardPage(){ this.navCtrl.push(Dashboard); }
  loginPage(){ this.navCtrl.push(UserLogin); }
  signupPage(){ this.navCtrl.push(UserSignup); }

//serach slect

  // getPorts(): Port[] {
  //       return [
  //           {  name: 'Tokai'  },
  //           {  name: 'Vladivostok' },
  //           { name: 'Navlakhi' },
           
  //       ];
  //   }
     portChange(event: { component: SelectSearchable, value: any }) {
      console.log("value:", event.value);
    }
      
   
}

class BloodGroup {
   // public id: number;
    public name: string;
    //public country: string;
}
