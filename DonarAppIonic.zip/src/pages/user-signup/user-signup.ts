import { Component, OnInit } from '@angular/core';
// import { NgForm } from "@angular/forms";
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Dashboard } from '../dashboard/dashboard';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { DashboardServices } from '../../providers/dashboard-services';
import { SelectSearchable } from "../../components/select/select";
import { Donar } from '../../_models/Donar';
// import { UserLogin } from '../user-login/user-login';
// import { UserForgotpassword } from '../user-forgotpassword/user-forgotpassword';


@IonicPage()
@Component({
  selector: 'page-user-signup',
  templateUrl: 'user-signup.html',
})
export class UserSignup implements OnInit {
  //donar={};
  //validation
   BloodGroups=[];
   private donar : FormGroup;
   countryList : any;
   stateList : any;
   cityList : any;
   donarObj : Donar;
   donarj : any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
  private formBuilder: FormBuilder, private dataService : DashboardServices) {
     this.donar = this.formBuilder.group({
      mobile: ['', Validators.required],
      name: [''],
      bloodGroup:[''],
      area: [''],
      city:[''],
      state: [''],
      country:['']
      });
     this.BloodGroups = [
            { name: 'A+'  },
            { name: 'A-' },
            { name: 'B+' },
            { name: 'B-' },
            { name: 'AB+' },
            { name: 'AB-' },
            { name: 'O+' },
            { name: 'O-' },
            { name: 'A1+' },
            { name: 'A1-' },
            { name: 'A2+' },
            { name: 'A2-' },
            { name: 'A1B+' },
            { name: 'A1B-' },
            { name: 'A2B+' },
            { name: 'A2B-' },
            { name: 'Bombay Blood Group' }
        ];
  }

  ngOnInit(){
    this.loadCountries();
  }

  addDonar(formVal){ 
    
    formVal.value.bloodGroup = formVal.value.bloodGroup.name;
    formVal.value.country = formVal.value.country.name;
    formVal.value.state = formVal.value.state.name;
    formVal.value.city = formVal.value.city.name;
    console.log(formVal.value);
    // console.log(this.donar.value.state.name);
    // console.log(this.donar.value.city.name);
    //this.donarObj.country = this.donar.value.country.name;
    //this.donarObj.state = this.donar.value.state.name;
    //this.donarObj.city = this.donar.value.city.name;
  //  console.log("new Donar"+this.donarObj);
   this.donarj = this.dataService.addDonar(formVal.value).subscribe(data => {
     this.donarj = data;
   });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad UserSignup');
  }

  dashboardPage(){ this.navCtrl.push(Dashboard); }
  // loginPage(){ this.navCtrl.push(UserLogin);}
  // forgotPasswordPage(){ this.navCtrl.push(UserForgotpassword);}

  loadCountries(){
    this.countryList = this.dataService.loadCountry().subscribe(data => {
      this.countryList = data[0].countries;
    });
  }

  loadStates(countryId : string){
    this.stateList = this.dataService.loadState(countryId).subscribe(data => {
      this.stateList = data;
    });
  }

  loadCities(stateId : string){
    this.cityList = this.dataService.loadCity(stateId).subscribe(data => {
      this.cityList = data;
    });
  }

  countryChange(event: { component: SelectSearchable, value: any }) {
    // console.log("countryChange value:", event.value);
   // this.donar.controls['country'].setValue(event.value.name);
    this.loadStates(event.value.coun_id);
  }

  stateChange(event: { component: SelectSearchable, value: any }) {
    // console.log("stateChange value:", event.value);
   // this.donar.controls['state'].setValue(event.value.name);
    this.loadCities(event.value.state_id);
  }

  cityChange(event: { component: SelectSearchable, value: any }) {
    // console.log("cityChange value:", event.value);
   // this.loadCities(event.value.state_id);
   //this.donar.controls['city'].setValue(event.value.name);
  }

  bloodGroupChange(event: { component: SelectSearchable, value: any }) {
   // this.donar.controls['bloodGroup'].setValue(event.value.name);
    console.log("bloodGroupChange value:", event.value.name);
  }

}


