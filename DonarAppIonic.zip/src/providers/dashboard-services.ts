import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response ,ResponseContentType} from '@angular/http';
import 'rxjs/add/operator/map';
import { Donar } from '../_models/Donar';

/*
  Generated class for the DashboardServices provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class DashboardServices {

  constructor(public http: Http) {
    console.log('Hello DashboardServices Provider');
  }

  data : any = {
    "area":"test","bloodGroup":"B+","city":"Achampudur","country":"India","mobile":"9638527415",
    "name":"sdfdaf","state":"Tamil Nadu"
  };

  url : string = "http://localhost:7700"; 
      /* To add donar details */
    addDonar(donar: Donar) {
        console.log(donar);
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url+'/newDonar', this.data, options).map((response: Response) => {
          console.log("res : "+response.json());

        });
    }

      /* To search donars details */
    searchDonar(donar: Donar) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post('/searchDonar', donar, options)
            .map((response: Response) => response.json());
    }

      /* To load country details */
    loadCountry() {
        return this.http.get(this.url+'/Countries').map((response: Response) => response.json());
    }

      /* To load states details */
    loadState(countryId: string) {
 
        return this.http.get(this.url+'/states/'+countryId).map((response: Response) => response.json());
    }
      /* To load citites details */
    loadCity(stateId: string) {
        return this.http.get(this.url+'/cities/'+stateId).map((response: Response) => response.json());
    }


}
