export * from "./Producer"
export * from "./Consumer"


import fs = require('ts-fs-promise');
 
 fs.readFile('some.txt', 'utf8').then((fileText:string) => {
    // do something
 });