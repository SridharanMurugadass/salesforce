package com.lucasmro.restaurant.enums;

public enum ProductType {
	HAMBURGUER,
	DRINK,
	DESSERT
}
