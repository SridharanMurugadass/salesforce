package com.lucasmro.restaurant.enums;

public enum OrderStatus {
	WAITING,
	PREPARING,
	READY,
	DELIVERED,
	CANCELED;
}
