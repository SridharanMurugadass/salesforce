package com.lucasmro.restaurant.serialization;

public class Group {
	public static class Public {}
	public static class Private extends Public {}
}
