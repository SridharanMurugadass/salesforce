package application;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

class Database {
	public int code;

	public String fname;
	public String Lname;
	public int reg;
	public int age;
	public String sec;

	MongoClientURI uri  = new MongoClientURI("mongodb://test:test@ds227119.mlab.com:27119/education");
	
	MongoClient client = new MongoClient(uri);
    DB db = client.getDB(uri.getDatabase());
    DBCollection coll = db.getCollection("test");
    
	public final String Database_name = "ghostEye";
	public final String Database_user = "root";
	public final String Database_pass = "root";

	public Connection con;

	public boolean init()  {
		/*try {
			Class.forName("com.mysql.jdbc.Driver");

			try {
				this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + Database_name, Database_user,
						Database_pass);
			} catch (SQLException e) {

				System.out.println("Error: Database Connection Failed ! Please check the connection Setting");

				return false;

			}

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

			return false;
		}*/

		return true;
	}

	public void insert() {
		
		
		//String sql = "INSERT INTO face_bio (code, first_name, last_name, reg, age , section) VALUES (?, ?, ?, ?,?,?)";

		//PreparedStatement statement = null;
		
		BasicDBObject tt = new BasicDBObject();
		tt.put("age",this.age);
		tt.put("_id",this.code);
		tt.put("fname",this.fname);
		tt.put("Lname",this.Lname);
		tt.put("reg",this.reg);
		tt.put("sec",this.sec);
		
		//System.out.println("testin the data"+tt);
		
		coll.insert(tt);
		/*try {
			statement = con.prepareStatement(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {

			statement.setInt(1, this.code);
			statement.setString(2, this.fname);

			statement.setString(3, this.Lname);
			statement.setInt(4, this.reg);
			statement.setInt(5, this.age);
			statement.setString(6, this.sec);

			int rowsInserted = statement.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new face data was inserted successfully!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

	public ArrayList<String> getUser(int inCode) throws SQLException {

		ArrayList<String> user = new ArrayList<String>();
		
		//System.out.println(inCode);
					
			BasicDBObject query=new BasicDBObject("_id",inCode);
			
			DBObject sss = coll.findOne(query);
			
			/*System.out.println(sss.get("_id"));
			System.out.println(sss.get("fname"));
			System.out.println(sss.get("Lname"));
			System.out.println(sss.get("reg"));
			System.out.println(sss.get("age"));
			System.out.println(sss.get("sec"));*/
			
			user.add(0, sss.get("_id").toString());
			user.add(1, sss.get("fname").toString());
			user.add(2, sss.get("Lname").toString());
			user.add(3, sss.get("reg").toString());
			user.add(4, sss.get("age").toString());
			user.add(5, sss.get("sec").toString());
		/*try {

			Database app = new Database();

			String sql = "select * from face_bio where code=" + inCode + " limit 1";

			Statement s = con.createStatement();

			ResultSet rs = s.executeQuery(sql);

			while (rs.next()) {*/

				/*
				 * app.setCode(rs.getInt(2)); app.setFname(rs.getString(3));
				 * app.setLname(rs.getString(4)); app.setReg(rs.getInt(5));
				 * app.setAge(rs.getInt(6)); app.setSec(rs.getString(7));
				 */

				

				/*
				 * System.out.println(app.getCode());
				 * System.out.println(app.getFname());
				 * System.out.println(app.getLname());
				 * System.out.println(app.getReg());
				 * System.out.println(app.getAge());
				 * System.out.println(app.getSec());
				 */

				// nString="Name:" + rs.getString(3)+" "+rs.getString(4) +
				// "\nReg:" + app.getReg() +"\nAge:"+app.getAge() +"\nSection:"
				// +app.getSec() ;

				// System.out.println(nString);
		/*	}

			con.close(); // closing connection
		} catch (Exception e) {
			e.getStackTrace();
		}
		System.out.println(user.toString());*/
			//System.out.println(user.toString());
			
		return user;
	}

	public void db_close() 
	{
		/*try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	public int getReg() {
		return reg;
	}

	public void setReg(int reg) {
		this.reg = reg;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSec() {
		return sec;
	}

	public void setSec(String sec) {
		this.sec = sec;
	}

}
